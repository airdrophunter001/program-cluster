/**
 * PB-RSFF (Predictive Bio-Mechanical & Reciprocal Social Force Framework)
 * 
 * AAA-Grade Crowd Dynamics & Physics-Based AI Engine
 * Designed for high-density, multi-agent predictive crowd pathfinding, organic biomechanics,
 * and signed-distance-field (SDF) environmental awareness.
 * 
 * Developed with Data-Oriented Design (DOD) principles to maximize spatial locality
 * and allow seamless integration into high-performance web-GL or HTML5 Canvas simulators.
 */

// -----------------------------------------------------------------------------
// [MATH & GEOMETRY UTILITIES]
// Robust 2D Vector structures and operations optimized for high-frequency physics
// -----------------------------------------------------------------------------
export interface Vector2D {
  x: number;
  y: number;
}

export class Vec2 {
  static create(x = 0, y = 0): Vector2D {
    return { x, y };
  }

  static add(a: Vector2D, b: Vector2D): Vector2D {
    return { x: a.x + b.x, y: a.y + b.y };
  }

  static sub(a: Vector2D, b: Vector2D): Vector2D {
    return { x: a.x - b.x, y: a.y - b.y };
  }

  static scale(v: Vector2D, s: number): Vector2D {
    return { x: v.x * s, y: v.y * s };
  }

  static dot(a: Vector2D, b: Vector2D): number {
    return a.x * b.x + a.y * b.y;
  }

  static cross(a: Vector2D, b: Vector2D): number {
    return a.x * b.y - a.y * b.x;
  }

  static len(v: Vector2D): number {
    return Math.hypot(v.x, v.y);
  }

  static norm(v: Vector2D): Vector2D {
    const l = Math.hypot(v.x, v.y);
    if (l === 0) return { x: 0, y: 0 };
    return { x: v.x / l, y: v.y / l };
  }

  static dist(a: Vector2D, b: Vector2D): number {
    return Math.hypot(a.x - b.x, a.y - b.y);
  }

  static perp(v: Vector2D): Vector2D {
    return { x: -v.y, y: v.x };
  }

  static limit(v: Vector2D, max: number): Vector2D {
    const l = Math.hypot(v.x, v.y);
    if (l > max) {
      return { x: (v.x / l) * max, y: (v.y / l) * max };
    }
    return { x: v.x, y: v.y };
  }
}

// -----------------------------------------------------------------------------
// [DATA DEFINITIONS]
// Struct-of-Arrays (SoA) friendly definitions for lightning-fast memory lookup
// -----------------------------------------------------------------------------
export interface PBRSFF_Agent {
  id: number;
  pos: Vector2D;          // Position vector
  vel: Vector2D;          // Speed Velocity vector
  mass: number;           // Agent mass (typically 60-80 kg in human models)
  radius: number;         // Physical radius (typically 0.25 - 0.3m)
  targetPos: Vector2D;    // Active destination coordinate
  desiredSpeed: number;   // Expected walking speed (e.g. 1.2 - 2.0 m/s)
  
  // ORCA / Social Force Parameters
  fovAngle: number;       // Field of view (degrees, e.g., 200 degrees)
  anisotropyLambda: number; // View orientation influence [0, 1]
  personalSpace: number;  // Social radius boundaries (interaction radius)
  
  // Biomechanical Gait / Ornstein-Uhlenbeck variables
  vNoise: Vector2D;       // Persistent Brownian drift state
  gaitPhase: number;      // Gait sinusoidal generator phase [0, 2*PI]
  
  // Spring-Dashpot network transient connectivity (for anti-tunneling)
  tensionConnections: number[]; // Connected agent IDs in micro-continuum state
}

// Simple Line Segment for environment boundary representations
export interface EnvWallSegment {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  slipCoefficient?: number; // Slip Friction modifier [0..1]
}

// Represents the Signed Distance Field query object
export interface SDF_Query_Result {
  signedDistance: number;    // negative if inside, positive if outside
  gradient: Vector2D;        // Direction of fastest increase in distance (points away from wall)
  slipTangent: Vector2D;     // Parallel wall slide vector
  nearestWallPoint: Vector2D;
}


// -----------------------------------------------------------------------------
// [MAIN PB-RSFF ENGINE SOLVER]
// -----------------------------------------------------------------------------
export class PBRSFF_Solver {
  // Model Parameters
  private relaxationTime = 0.5; // Tau (seconds) for goal acquisition
  private socialA = 2.4;        // Repulsion scaling strength A_i
  private socialB = 0.32;       // Repulsion decay rate B_i
  private ouTheta = 2.0;        // Mean-reversion parameter of Ornstein-Uhlenbeck process
  private ouSigma = 0.45;       // Variance multiplier for Brownian fluctuations
  private gaitFreqFactor = 2.1; // Relationship factor between velocity and gait oscillation
  private gaitAmp = 0.12;       // Sinusoid amplitude for lifelike head-sways
  private densityThreshold = 5.0; // Critical local density threshold (agents per m^2)
  private springConstant = 40.0;  // Viscoelastic spring stiffness (K)
  private damperConstant = 12.0;  // Viscoelastic damping coefficient (C)

  constructor(options?: {
    socialA?: number;
    socialB?: number;
    ouTheta?: number;
    ouSigma?: number;
    springConst?: number;
  }) {
    if (options?.socialA !== undefined) this.socialA = options.socialA;
    if (options?.socialB !== undefined) this.socialB = options.socialB;
    if (options?.ouTheta !== undefined) this.ouTheta = options.ouTheta;
    if (options?.ouSigma !== undefined) this.ouSigma = options.ouSigma;
    if (options?.springConst !== undefined) this.springConstant = options.springConst;
  }

  /**
   * Evaluates Signed Distance Field (SDF) of the nearest physical wall segment.
   * This is computed mathematically on-the-fly for any collection of line segments.
   */
  public evaluateSDF(pos: Vector2D, walls: EnvWallSegment[]): SDF_Query_Result {
    let minDistance = Infinity;
    let nearestPoint: Vector2D = { x: pos.x, y: pos.y };
    let wallDir: Vector2D = { x: 1, y: 0 };
    let slipTangent: Vector2D = { x: 0, y: 1 };

    for (const w of walls) {
      const wx = w.x2 - w.x1;
      const wy = w.y2 - w.y1;
      const lenSq = wx * wx + wy * wy;
      if (lenSq === 0) continue;

      // Project agent position onto wall segment line to find closest point
      const t = Math.max(0, Math.min(1, ((pos.x - w.x1) * wx + (pos.y - w.y1) * wy) / lenSq));
      const px = w.x1 + t * wx;
      const py = w.y1 + t * wy;
      const dist = Math.hypot(pos.x - px, pos.y - py);

      if (dist < minDistance) {
        minDistance = dist;
        nearestPoint = { x: px, y: py };
        wallDir = { x: wx, y: wy };
      }
    }

    // Normal gradient vector points away from the wall to the agent
    let gradient = Vec2.sub(pos, nearestPoint);
    const gradLen = Vec2.len(gradient);
    if (gradLen > 0) {
      gradient = Vec2.scale(gradient, 1 / gradLen);
    } else {
      gradient = { x: 0, y: 1 }; // Default direction if sitting perfectly on wall
    }

    // Slip Tangent direction (perpendicular to wall's normal vector)
    const wallTangentNorm = Vec2.norm(wallDir);

    return {
      signedDistance: minDistance,
      gradient,
      slipTangent: wallTangentNorm,
      nearestWallPoint: nearestPoint
    };
  }

  /**
   * Computes reciprocal ORCA-like velocity constraints to preemptively avoid other agents
   */
  private computeORCAVelocity(agent: PBRSFF_Agent, neighbors: PBRSFF_Agent[]): Vector2D {
    let avoidForce = Vec2.create(0, 0);
    const timeHorizon = 1.5; // Seconds in the future to preview collisions

    for (const b of neighbors) {
      if (b.id === agent.id) continue;

      // Distance and combined radii
      const dp = Vec2.sub(b.pos, agent.pos);
      const dist = Vec2.len(dp);
      const r_comb = agent.radius + b.radius;
      if (dist === 0) continue;

      // Relative velocity projection
      const rv = Vec2.sub(agent.vel, b.vel);

      // Relative separation vector
      const normSep = Vec2.scale(dp, 1 / dist);

      // Check for impending collision within time horizon
      const relativeSpeedAlongNormal = Vec2.dot(rv, normSep);
      if (relativeSpeedAlongNormal > 0) {
        // Heading towards each other
        const timeToCollide = (dist - r_comb) / relativeSpeedAlongNormal;
        if (timeToCollide > 0 && timeToCollide < timeHorizon) {
          // Preemptive ORCA Correction Force
          // Inverse weighting: closer collision creates much stronger evasion pressure
          const weight = (timeHorizon - timeToCollide) / timeHorizon;
          const forceMag = (agent.desiredSpeed * weight * 1.5) / (dist + 0.05);

          // Evasion vector pushes perpendicular to collision trajectory or along normal
          const evadeDir = Vec2.norm(Vec2.sub(rv, Vec2.scale(normSep, relativeSpeedAlongNormal)));
          const orcaCorrection = Vec2.scale(evadeDir, forceMag);

          avoidForce = Vec2.add(avoidForce, orcaCorrection);
        }
      }
    }

    return avoidForce;
  }

  /**
   * Main mathematical integrator updating a list of agents inside the physical sandbox.
   * Modifies agents in-place based on the non-linear coupling equation.
   * 
   * @param agents Array of PBRSFF_Agent active in sandbox area.
   * @param walls Static wall segments creating walls and obstacle boundaries.
   * @param dt High-fidelity time differential (frame time).
   * @param k Sandbox dimension width/height boundaries.
   */
  public updateSimulation(
    agents: PBRSFF_Agent[],
    walls: EnvWallSegment[],
    dt: number,
    k: number
  ): void {
    if (dt <= 0) return;
    const NUM_AGENTS = agents.length;

    // Buffer array to hold computed forces (DoD safe allocation)
    const accels: Vector2D[] = Array.from({ length: NUM_AGENTS }, () => Vec2.create(0, 0));

    // Dynamic Spatial Binning / Local density evaluation
    const localDensities = new Float32Array(NUM_AGENTS);
    const searchRadius = 1.25; // Define density scan envelope (meters)

    for (let i = 0; i < NUM_AGENTS; i++) {
      let neighborCount = 0;
      for (let j = 0; j < NUM_AGENTS; j++) {
        if (Vec2.dist(agents[i].pos, agents[j].pos) < searchRadius) {
          neighborCount++;
        }
      }
      // Density evaluated as Area density (number of agents per scan envelope area)
      localDensities[i] = neighborCount / (Math.PI * searchRadius * searchRadius);
    }

    // Update Ornstein-Uhlenbeck noise variables and phase couplings first
    for (const agent of agents) {
      // 1. Ornstein-Uhlenbeck stochastic differential solver
      // dV = -theta * V * dt + sigma * sqrt(dt) * dW
      const dw_x = (Math.random() - 0.5) * 2; // Approximates Wiener process element
      const dw_y = (Math.random() - 0.5) * 2;
      const rndSqr = Math.sqrt(dt);

      agent.vNoise.x += -this.ouTheta * agent.vNoise.x * dt + this.ouSigma * rndSqr * dw_x;
      agent.vNoise.y += -this.ouTheta * agent.vNoise.y * dt + this.ouSigma * rndSqr * dw_y;

      // 2. Gait Phase incrementation: frequency scales with actual current velocity
      const speedMag = Vec2.len(agent.vel);
      const frequency = this.gaitFreqFactor * (speedMag + 0.2); // natural gait frequency
      agent.gaitPhase = (agent.gaitPhase + frequency * dt) % (Math.PI * 2);
    }

    // Core forces calculations
    for (let i = 0; i < NUM_AGENTS; i++) {
      const agent = agents[i];
      let F_total = Vec2.create(0, 0);

      // -----------------------------------------------------------------------
      // MODULE 1: Goal-driven Steering acceleration (a_goal)
      // -----------------------------------------------------------------------
      const targetDir = Vec2.sub(agent.targetPos, agent.pos);
      const targetDist = Vec2.len(targetDir);
      let targetVel = Vec2.create(0, 0);

      if (targetDist > 0.05) {
        // Normalize direction and multiply by desired speed limit
        targetVel = Vec2.scale(Vec2.scale(targetDir, 1 / targetDist), agent.desiredSpeed);
      }

      // a_goal = (v_desired - v_current) / RelaxationTime
      const a_goal = Vec2.scale(Vec2.sub(targetVel, agent.vel), 1 / this.relaxationTime);
      F_total = Vec2.add(F_total, a_goal);

      // -----------------------------------------------------------------------
      // MODULE 2: ORCA Velocity Evasion Constraints (a_orca)
      // -----------------------------------------------------------------------
      const a_orca = this.computeORCAVelocity(agent, agents);
      F_total = Vec2.add(F_total, a_orca);

      // -----------------------------------------------------------------------
      // MODULE 3: Anisotropic Social Force interaction with neighbors (f_social)
      // -----------------------------------------------------------------------
      let F_social_accum = Vec2.create(0, 0);
      const agentDir = Vec2.norm(agent.vel); // Agent heading

      for (let j = 0; j < NUM_AGENTS; j++) {
        if (i === j) continue;
        const other = agents[j];

        const r_ij = agent.radius + other.radius;
        const d_vec = Vec2.sub(other.pos, agent.pos);
        const d_ij = Vec2.len(d_vec);

        if (d_ij > 0 && d_ij < agent.personalSpace) {
          const n_ij = Vec2.scale(d_vec, -1 / d_ij); // Repulsion vector (pointing away from neighbor)

          // Isotropic force magnitude: A_i * exp((r_ij - d_ij) / B_i)
          let forceMag = this.socialA * Math.exp((r_ij - d_ij) / this.socialB);

          // Anisotropy vision angle check
          // If neighbor is behind field-of-view, scaled down by field coefficient
          const cosTheta = Vec2.dot(agentDir, Vec2.scale(d_vec, 1 / d_ij));
          const cosLimit = Math.cos((agent.fovAngle / 2) * (Math.PI / 180));
          
          let W_theta = 1.0;
          if (cosTheta < cosLimit) {
            W_theta = agent.anisotropyLambda; // Reduced repulsive effect outside visual cone
          }

          F_social_accum = Vec2.add(F_social_accum, Vec2.scale(n_ij, forceMag * W_theta));
        }
      }
      F_total = Vec2.add(F_total, F_social_accum);

      // -----------------------------------------------------------------------
      // MODULE 4: Signed Distance Field Gradient & Boundary Slip Mechanics (a_sdf)
      // -----------------------------------------------------------------------
      if (walls.length > 0) {
        const sdfResult = this.evaluateSDF(agent.pos, walls);
        const D_wall = sdfResult.signedDistance;

        // Apply boundary wall repulsion as distance approaches collision radius
        const collisionMargin = agent.radius + 0.15;
        if (D_wall < collisionMargin) {
          const depth = collisionMargin - D_wall;
          
          // Logarithmic SDF gradient push-back force
          const forceMagSDF = 8.0 * Math.log(1.0 + (depth / Math.max(0.01, D_wall)));
          const a_sdf_repulsion = Vec2.scale(sdfResult.gradient, forceMagSDF);

          // Boundary friction tensor integration: 
          // Keep slip parallel tangent velocity and dampen friction perpendicular velocity
          const slipCoeff = 0.85; // Boundary sliding efficiency modifier
          const tangentComp = Vec2.dot(agent.vel, sdfResult.slipTangent);
          const tangentialSlipVel = Vec2.scale(sdfResult.slipTangent, tangentComp * slipCoeff);
          
          // Reassign agent velocity component to slither along tangent lines dynamically
          agent.vel.x = agent.vel.x * 0.15 + tangentialSlipVel.x * 0.85;
          agent.vel.y = agent.vel.y * 0.15 + tangentialSlipVel.y * 0.85;

          F_total = Vec2.add(F_total, a_sdf_repulsion);
        }
      }

      // -----------------------------------------------------------------------
      // MODULE 5: Ornstein-Uhlenbeck micro-noise & Gait periodicity (a_gait)
      // -----------------------------------------------------------------------
      // Gait-phase oscillation perpendicular to movement vector:
      const perpHeading = Vec2.perp(Vec2.norm(agent.vel));
      const swayAmplitude = this.gaitAmp * agent.desiredSpeed;
      const gaitOscillation = Vec2.scale(perpHeading, swayAmplitude * Math.sin(agent.gaitPhase));

      // combine Brownian noise and biomechanical shoulder-sway
      const a_gait = Vec2.add(agent.vNoise, gaitOscillation);
      F_total = Vec2.add(F_total, a_gait);

      // -----------------------------------------------------------------------
      // MODULE 6: Local High-Density Constraint & Viscoelastic Network
      // -----------------------------------------------------------------------
      if (localDensities[i] > this.densityThreshold) {
        let F_viscoelastic = Vec2.create(0, 0);

        // Scan nearby neighbors within localized tension radius
        const connectionRadius = agent.radius * 2.3;
        for (let j = 0; j < NUM_AGENTS; j++) {
          if (i === j) continue;
          const other = agents[j];
          const dist = Vec2.dist(agent.pos, other.pos);

          if (dist < connectionRadius && dist > 0.01) {
            // Act as a spring-dashpot damper system
            const overlap = connectionRadius - dist;
            const normDir = Vec2.scale(Vec2.sub(other.pos, agent.pos), 1 / dist);

            // 1. Hooke's elastic restoring spring force
            const springForce = this.springConstant * overlap;

            // 2. Linear damping viscous dashpot force (velocity difference along line)
            const relativeVel = Vec2.sub(other.vel, agent.vel);
            const relativeVelAlongNormal = Vec2.dot(relativeVel, normDir);
            const dampingForce = this.damperConstant * relativeVelAlongNormal;

            // Total cohesive force applied symmetrically
            const f_bond = Vec2.scale(normDir, -(springForce + dampingForce));
            F_viscoelastic = Vec2.add(F_viscoelastic, f_bond);
          }
        }
        F_total = Vec2.add(F_total, F_viscoelastic);
      }

      // Save calculated force to buffer
      accels[i] = F_total;
    }

    // Integrate forces to velocities, then velocities to coordinates
    for (let i = 0; i < NUM_AGENTS; i++) {
      const agent = agents[i];
      
      // Update velocities (Euler-Cromer integration step: stable for physics systems)
      agent.vel.x += accels[i].x * dt;
      agent.vel.y += accels[i].y * dt;

      // Bound velocity magnitude to safety threshold to prevent chaotic explosions
      const speedCap = agent.desiredSpeed * 1.5;
      agent.vel = Vec2.limit(agent.vel, speedCap);

      // Update positions
      agent.pos.x += agent.vel.x * dt;
      agent.pos.y += agent.vel.y * dt;

      // Soft constraints: Keep inside sandbox viewport boundary margins
      const borderPadding = agent.radius + 0.1;
      if (agent.pos.x < borderPadding) {
        agent.pos.x = borderPadding;
        agent.vel.x *= -0.4; // Rebounce with drag energy loss
      } else if (agent.pos.x > k - borderPadding) {
        agent.pos.x = k - borderPadding;
        agent.vel.x *= -0.4;
      }

      if (agent.pos.y < borderPadding) {
        agent.pos.y = borderPadding;
        agent.vel.y *= -0.4;
      } else if (agent.pos.y > k - borderPadding) {
        agent.pos.y = k - borderPadding;
        agent.vel.y *= -0.4;
      }
    }
  }
}
