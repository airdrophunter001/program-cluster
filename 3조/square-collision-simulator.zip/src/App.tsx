/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Settings2, 
  BarChart3, 
  Info, 
  Heart, 
  Users, 
  Shield, 
  Skull, 
  TrendingUp, 
  Copy, 
  Download, 
  Clock,
  Terminal, 
  Check, 
  BookOpen, 
  X,
  Sparkles,
  Lock,
  Navigation,
  ShieldAlert,
  Plus
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, LineChart, Line, XAxis, YAxis } from 'recharts';

// Global Constants
const OBJECT_DIAMETER = 0.5;
const OBJECT_RADIUS = OBJECT_DIAMETER / 2;
const MAX_POPULATION = 200; // Safe cap to prevent client-side frame rate drops
const MOVE_PROBABILITY = 0.25;

enum Status {
  SUSCEPTIBLE = 'SUSCEPTIBLE',
  INFECTED = 'INFECTED',
  RECOVERED = 'RECOVERED',
  DEAD = 'DEAD'
}

interface BallDiseaseState {
  status: Status;
  immunityTimeRemaining: number;
  infectedAt?: number;
  infectionsCount?: number;
}

interface Ball {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  isMoving: boolean;
  status: Status;
  immunityTimeRemaining: number;
  opacity: number; // For smooth fade-out when dead
  targetX?: number;
  targetY?: number;
  baseTargetX?: number;
  baseTargetY?: number;
  altTarget1X?: number;
  altTarget1Y?: number;
  altTarget2X?: number;
  altTarget2Y?: number;
  selectedTargetIndex?: number;
  choiceDecisionCounter?: number;
  trail?: { x: number; y: number }[];
  stayTimeRemaining?: number;
  infectionsCount?: number;
  infectedAt?: number;
  isVaccinated?: boolean;
  diseaseStates?: { [diseaseId: number]: BallDiseaseState };
}

interface HistoryData {
  time: number;
  susceptible: number;
  infected: number;
  recovered: number;
  dead: number;
  total: number;
}

interface EmpiricalStats {
  completedCount: number;
  totalSecondaryInfections: number;
  totalDuration: number;
  diseaseDeaths: number;
  recoveries: number;
}

// Preset environment definitions
interface Preset {
  name: string;
  k: number;
  n: number;
  transmissionProb: number;
  birthRate: number;
  naturalDeathRate: number;
  infectionDeathRate: number;
  recoveryRate: number;
  speed: number;
  decisionInterval: number;
  description: string;
  icon: string;
}

const PRESETS: Record<string, Preset> = {
  normal: {
    name: "기본 지역 사회 (Normal Community)",
    k: 15,
    n: 45,
    transmissionProb: 35,
    birthRate: 0.15,
    naturalDeathRate: 0.08,
    infectionDeathRate: 8,
    recoveryRate: 15,
    speed: 6,
    decisionInterval: 100,
    description: "밀도와 기동성의 균형이 잡혀 있는 일반 전파 모델입니다.",
    icon: "🌐"
  },
  school: {
    name: "초등학교 교실 (Classroom)",
    k: 10,
    n: 65,
    transmissionProb: 60,
    birthRate: 0.0,
    naturalDeathRate: 0.01,
    infectionDeathRate: 1.5,
    recoveryRate: 25,
    speed: 7.5,
    decisionInterval: 100,
    description: "협소하고 고밀도인 공간입니다. 전파 속도가 빠르고 면역 회복률이 높습니다.",
    icon: "🏫"
  },
  office: {
    name: "화이트칼라 사무실 (Office Workspace)",
    k: 18,
    n: 30,
    transmissionProb: 20,
    birthRate: 0.02,
    naturalDeathRate: 0.04,
    infectionDeathRate: 5,
    recoveryRate: 12,
    speed: 3.2,
    decisionInterval: 100,
    description: "좌식 위주의 기동성이 차단된 환경입니다. 대면 상호작용 빈도가 상대적으로 적습니다.",
    icon: "💼"
  },
  subway: {
    name: "출근길 지하철 (Subway Gridlock)",
    k: 7,
    n: 85,
    transmissionProb: 85,
    birthRate: 0.0,
    naturalDeathRate: 0.0,
    infectionDeathRate: 10,
    recoveryRate: 8,
    speed: 1.2,
    decisionInterval: 100,
    description: "극도의 초밀집 정지 공간입니다. 환기율이 제한적이고 접촉 시 고확률 전염이 유발됩니다.",
    icon: "🚇"
  },
  park: {
    name: "주말 야외 축제 (Weekend Festival)",
    k: 26,
    n: 35,
    transmissionProb: 12,
    birthRate: 0.25,
    naturalDeathRate: 0.06,
    infectionDeathRate: 4,
    recoveryRate: 20,
    speed: 8.5,
    decisionInterval: 100,
    description: "개방된 넓은 공간입니다. 기동 속도는 빠르나 공기 희석과 낮은 유효 충돌률을 가집니다.",
    icon: "🌳"
  },
  hospital: {
    name: "종합병원 격리 병실 (Quarantine Ward)",
    k: 16,
    n: 50,
    transmissionProb: 45,
    birthRate: 0.0,
    naturalDeathRate: 0.1,
    infectionDeathRate: 15,
    recoveryRate: 20,
    speed: 4,
    decisionInterval: 100,
    description: "벽과 침상으로 분리되어 격리 중인 병동입니다. 목적을 가지고 움직이는 의사, 간호사, 환자가 실시간으로 교차합니다.",
    icon: "🏥"
  }
};

interface DiseaseInfo {
  name: string;
  r0: string;
  ifr: string;
  duration: string;
  desc: string;
  transmissionProb: number;
  recoveryRate: number;
  infectionDeathRate: number;
  immunityDuration: number;
}

const HISTORICAL_ORGANISMS: DiseaseInfo[] = [
  {
    name: "홍역 (Measles)",
    r0: "12.0 ~ 18.0 (초고전염성)",
    ifr: "0.1% ~ 0.2%",
    duration: "10 ~ 14일",
    desc: "공기 중 전파력이 가장 강력한 질환 중 하나로, 집단 면역 역치가 매우 높음(95% 이상).",
    transmissionProb: 98,
    recoveryRate: 8,
    infectionDeathRate: 0.012,
    immunityDuration: 40
  },
  {
    name: "메르스 (MERS-CoV)",
    r0: "0.4 ~ 0.9 (낮은 전파력)",
    ifr: "30.0% ~ 35.0%",
    duration: "10 ~ 14일",
    desc: "치명률이 매우 강하나 보건 환경 내 밀접 접촉 외 일반적인 공공 전파력은 상대적으로 낮음.",
    transmissionProb: 15,
    recoveryRate: 14,
    infectionDeathRate: 7,
    immunityDuration: 25
  },
  {
    name: "천연두 (Smallpox)",
    r0: "3.5 ~ 6.0",
    ifr: "30.0%",
    duration: "10 ~ 14일",
    desc: "인류가 백신으로 전멸시킨 유일한 감염병으로 가피 및 전신 발진 접촉 전파가 주 기전임.",
    transmissionProb: 55,
    recoveryRate: 13,
    infectionDeathRate: 5.5,
    immunityDuration: 35
  },
  {
    name: "코로나19 (COVID-19)",
    r0: "2.5 ~ 5.0 (변이 전)",
    ifr: "1.0% ~ 2.0% (초기)",
    duration: "10 ~ 14일",
    desc: "높은 무증상 전파 및 빠른 호흡기 복제로 인해 글로벌 대유행을 초래한 대표 전염병.",
    transmissionProb: 40,
    recoveryRate: 15,
    infectionDeathRate: 0.3,
    immunityDuration: 25
  },
  {
    name: "사스 (SARS)",
    r0: "2.0 ~ 4.0",
    ifr: "10.0%",
    duration: "7 ~ 14일",
    desc: "치명률과 전파 속도의 균형을 이뤄 격리 및 검역 정책으로 종식된 호흡기 증후군.",
    transmissionProb: 30,
    recoveryRate: 14,
    infectionDeathRate: 1.55,
    immunityDuration: 25
  },
  {
    name: "계절성 독감 (Seasonal Influenza)",
    r0: "1.3 ~ 1.8",
    ifr: "0.1% 미만",
    duration: "3 ~ 7일",
    desc: "주기적인 항원 소변이로 인해 매년 전파되나 인플루엔자 백신과 타미플루 등이 존재.",
    transmissionProb: 16,
    recoveryRate: 25,
    infectionDeathRate: 0.02,
    immunityDuration: 15
  }
];

interface WallSegment {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  x_min: number;
  x_max: number;
  y_min: number;
  y_max: number;
  isDoor?: boolean;
  doorName?: string;
  horizontal: boolean;
}

// Generate wall definitions with door parameters based on presets
function getPresetWalls(presetKey: string, k: number, doorsClosed: boolean): WallSegment[] {
  const walls: WallSegment[] = [];

  if (presetKey === 'hospital') {
    const mid = k / 2;
    const doorSize = 1.2;

    // Outer and Inner separation partitions: Horizontal wall at y = mid with door gap
    walls.push({ x1: 0, y1: mid, x2: mid - doorSize, y2: mid, x_min: 0, x_max: mid - doorSize, y_min: mid, y_max: mid, horizontal: true });
    walls.push({ x1: mid + doorSize, y1: mid, x2: k, y2: mid, x_min: mid + doorSize, x_max: k, y_min: mid, y_max: mid, horizontal: true });

    // Inner separation partitions: Vertical wall at x = mid with door gap
    walls.push({ x1: mid, y1: 0, x2: mid, y2: mid - doorSize, x_min: mid, x_max: mid, y_min: 0, y_max: mid - doorSize, horizontal: false });
    walls.push({ x1: mid, y1: mid + doorSize, x2: mid, y2: k, x_min: mid, x_max: mid, y_min: mid + doorSize, y_max: k, horizontal: false });

    // When quarantine doors are closed, seal the gaps with door walls
    if (doorsClosed) {
      walls.push({ x1: mid - doorSize, y1: mid, x2: mid + doorSize, y2: mid, x_min: mid - doorSize, x_max: mid + doorSize, y_min: mid, y_max: mid, isDoor: true, doorName: "가로 격리 차단문", horizontal: true });
      walls.push({ x1: mid, y1: mid - doorSize, x2: mid, y2: mid + doorSize, x_min: mid, x_max: mid, y_min: mid - doorSize, y_max: mid + doorSize, isDoor: true, doorName: "세로 격리 차단문", horizontal: false });
    }
  } else if (presetKey === 'office') {
    // Board room wall H (0 to 7 at y=6), V (x=7 from 0 to 6)
    walls.push({ x1: 0, y1: 6, x2: 3.5, y2: 6, x_min: 0, x_max: 3.5, y_min: 6, y_max: 6, horizontal: true });
    walls.push({ x1: 5.0, y1: 6, x2: 7, y2: 6, x_min: 5.0, x_max: 7, y_min: 6, y_max: 6, horizontal: true });
    walls.push({ x1: 7, y1: 0, x2: 7, y2: 6, x_min: 7, x_max: 7, y_min: 0, y_max: 6, horizontal: false });
    if (doorsClosed) {
      walls.push({ x1: 3.5, y1: 6, x2: 5.0, y2: 6, x_min: 3.5, x_max: 5.0, y_min: 6, y_max: 6, isDoor: true, doorName: "회의실 도어", horizontal: true });
    }
  } else if (presetKey === 'school') {
    const mid = k / 2;
    walls.push({ x1: 0, y1: 2.5, x2: mid - 1.0, y2: 2.5, x_min: 0, x_max: mid - 1.0, y_min: 2.5, y_max: 2.5, horizontal: true });
    walls.push({ x1: mid + 1.0, y1: 2.5, x2: k, y2: 2.5, x_min: mid + 1.0, x_max: k, y_min: 2.5, y_max: 2.5, horizontal: true });
    if (doorsClosed) {
      walls.push({ x1: mid - 1.0, y1: 2.5, x2: mid + 1.0, y2: 2.5, x_min: mid - 1.0, x_max: mid + 1.0, y_min: 2.5, y_max: 2.5, isDoor: true, doorName: "앞문 차단", horizontal: true });
    }
  } else if (presetKey === 'park') {
    // Festival Stage barrier
    walls.push({ x1: 3, y1: 4.2, x2: k - 3, y2: 4.2, x_min: 3, x_max: k - 3, y_min: 4.2, y_max: 4.2, horizontal: true });
    if (doorsClosed) {
      walls.push({ x1: k / 2 - 1.0, y1: 4.2, x2: k / 2 + 1.0, y2: 4.2, x_min: k / 2 - 1.0, x_max: k / 2 + 1.0, y_min: 4.2, y_max: 4.2, isDoor: true, doorName: "무대 게이트", horizontal: true });
    }
  }

  return walls;
}

// Pure physics solver for vertical/horizontal boundary wall segments
function resolveWallCollisions(b: Ball, walls: WallSegment[], slide: boolean = true) {
  for (let i = 0; i < walls.length; i++) {
    const wall = walls[i];
    if (wall.horizontal) {
      if (b.x >= wall.x_min - OBJECT_RADIUS && b.x <= wall.x_max + OBJECT_RADIUS) {
        const dist = b.y - wall.y1;
        const absDist = dist < 0 ? -dist : dist;
        if (absDist < OBJECT_RADIUS) {
          const isMovingTowards = (dist > 0 && b.vy < 0) || (dist < 0 && b.vy > 0);
          if (isMovingTowards || absDist < OBJECT_RADIUS - 0.01) {
            b.vy = -b.vy;
            b.y = wall.y1 + (dist < 0 ? -OBJECT_RADIUS : OBJECT_RADIUS);
            
            // Decreased pause time upon hitting a wall, and select a different target among available options
            b.stayTimeRemaining = 0.12 + Math.random() * 0.18; // Much faster, responsive decision pacing (0.12 to 0.3s)
            
            if (b.selectedTargetIndex !== undefined && b.baseTargetX !== undefined && b.baseTargetY !== undefined) {
              const otherIndices = [0, 1, 2].filter((idx) => idx !== b.selectedTargetIndex);
              const newSelectedIdx = otherIndices[Math.floor(Math.random() * otherIndices.length)];
              b.selectedTargetIndex = newSelectedIdx;
              
              const choices = [
                { x: b.baseTargetX, y: b.baseTargetY },
                { x: b.altTarget1X, y: b.altTarget1Y },
                { x: b.altTarget2X, y: b.altTarget2Y }
              ];
              const choice = choices[newSelectedIdx];
              if (choice && choice.x !== undefined && choice.y !== undefined) {
                b.targetX = choice.x;
                b.targetY = choice.y;
              } else {
                b.targetX = undefined;
                b.targetY = undefined;
              }
            } else {
              b.targetX = undefined;
              b.targetY = undefined;
            }
            
            if (!slide) {
              // Non-sliding fully stops
              b.vx = 0;
              b.vy = 0;
            } else {
              b.vy *= 0.35; // Dampen the perpendicular rebound slightly for smoother flow
            }
          }
        }
      }
    } else {
      if (b.y >= wall.y_min - OBJECT_RADIUS && b.y <= wall.y_max + OBJECT_RADIUS) {
        const dist = b.x - wall.x1;
        const absDist = dist < 0 ? -dist : dist;
        if (absDist < OBJECT_RADIUS) {
          const isMovingTowards = (dist > 0 && b.vx < 0) || (dist < 0 && b.vx > 0);
          if (isMovingTowards || absDist < OBJECT_RADIUS - 0.01) {
            b.vx = -b.vx;
            b.x = wall.x1 + (dist < 0 ? -OBJECT_RADIUS : OBJECT_RADIUS);
            
            // Decreased pause time upon hitting a wall, and select a different target among available options
            b.stayTimeRemaining = 0.12 + Math.random() * 0.18; // Much faster, responsive decision pacing (0.12 to 0.3s)
            
            if (b.selectedTargetIndex !== undefined && b.baseTargetX !== undefined && b.baseTargetY !== undefined) {
              const otherIndices = [0, 1, 2].filter((idx) => idx !== b.selectedTargetIndex);
              const newSelectedIdx = otherIndices[Math.floor(Math.random() * otherIndices.length)];
              b.selectedTargetIndex = newSelectedIdx;
              
              const choices = [
                { x: b.baseTargetX, y: b.baseTargetY },
                { x: b.altTarget1X, y: b.altTarget1Y },
                { x: b.altTarget2X, y: b.altTarget2Y }
              ];
              const choice = choices[newSelectedIdx];
              if (choice && choice.x !== undefined && choice.y !== undefined) {
                b.targetX = choice.x;
                b.targetY = choice.y;
              } else {
                b.targetX = undefined;
                b.targetY = undefined;
              }
            } else {
              b.targetX = undefined;
              b.targetY = undefined;
            }
            
            if (!slide) {
              b.vx = 0;
              b.vy = 0;
            } else {
              b.vx *= 0.35; // Dampen the perpendicular rebound slightly
            }
          }
        }
      }
    }
  }
}

// Pure physics solver for physical agent-to-agent elastic/spring collisions
function resolveBallCollisions(balls: Ball[], k: number, activePreset: string, bounceElasticity: number = 0.45) {
  for (let i = 0; i < balls.length; i++) {
    const b1 = balls[i];
    if (b1.status === Status.DEAD) continue;
    for (let j = i + 1; j < balls.length; j++) {
      const b2 = balls[j];
      if (b2.status === Status.DEAD) continue;

      const dx = b2.x - b1.x;
      const dy = b2.y - b1.y;
      const dist = Math.hypot(dx, dy);
      const minDist = OBJECT_DIAMETER;

      if (dist < minDist) {
        // Overlap depth
        const overlap = minDist - dist;
        if (dist === 0) continue; // prevent division by zero

        // Soft, springy position correction to avoid sticky/overlapping behavior
        const nx = dx / dist;
        const ny = dy / dist;

        const pushX = nx * overlap * 0.5 * 0.85; // slightly dampened push-back to prevent hyper-active shaking
        const pushY = ny * overlap * 0.5 * 0.85;

        b1.x -= pushX;
        b1.y -= pushY;
        b2.x += pushX;
        b2.y += pushY;

        // Relative velocity
        const rvx = b2.vx - b1.vx;
        const rvy = b2.vy - b1.vy;

        // Velocity relative along the normal vector
        const velAlongNormal = rvx * nx + rvy * ny;

        // Resolve only if they are heading towards each other
        if (velAlongNormal < 0) {
          const impulse = -(1 + bounceElasticity) * velAlongNormal;
          
          // Distribute impulse equally (mass of each agent = 1)
          const impulseX = (impulse / 2) * nx;
          const impulseY = (impulse / 2) * ny;

          b1.vx -= impulseX;
          b1.vy -= impulseY;
          b2.vx += impulseX;
          b2.vy += impulseY;
        }
      }
    }
  }
}

function ccw(ax: number, ay: number, bx: number, by: number, cx: number, cy: number): boolean {
  return (cy - ay) * (bx - ax) > (by - ay) * (cx - ax);
}

function segmentsIntersect(
  ax: number, ay: number, bx: number, by: number,
  cx: number, cy: number, dx: number, dy: number
): boolean {
  return ccw(ax, ay, cx, cy, dx, dy) !== ccw(bx, by, cx, cy, dx, dy) &&
         ccw(ax, ay, bx, by, cx, cy) !== ccw(ax, ay, bx, by, dx, dy);
}

// Select random target positions inside designated rooms / zones with human intentionality
function getRandomPresetTarget(presetKey: string, k: number) {
  if (presetKey === 'hospital') {
    const r = Math.random();
    if (r < 0.22) { // Isolation Ward 1 (Top-Left corner bed)
      return { x: 1.5 + Math.random() * 3, y: 1.5 + Math.random() * 3 };
    } else if (r < 0.44) { // Isolation Ward 2 (Top-Right corner bed)
      return { x: k - 4.5 + Math.random() * 3, y: 1.5 + Math.random() * 3 };
    } else if (r < 0.66) { // Isolation Ward 3 (Bottom-Left corner bed)
      return { x: 1.5 + Math.random() * 3, y: k - 4.5 + Math.random() * 3 };
    } else if (r < 0.88) { // Isolation Ward 4 (Bottom-Right corner bed)
      return { x: k - 4.5 + Math.random() * 3, y: k - 4.5 + Math.random() * 3 };
    } else { // Central Nurse station and hallway hub
      return { x: k / 2 + (Math.random() - 0.5) * 1.5, y: k / 2 + (Math.random() - 0.5) * 1.5 };
    }
  } else if (presetKey === 'school') {
    const r = Math.random();
    if (r < 0.15) { // Podium
      return { x: 3 + Math.random() * 4, y: 1.2 + Math.random() * 1.2 };
    } else if (r < 0.8) { // Pick a student desk
      const row = Math.floor(Math.random() * 4);
      const col = Math.floor(Math.random() * 3);
      return { x: 1.5 + col * 2.8 + Math.random() * 1.4, y: 3.5 + row * 1.5 + Math.random() * 0.7 };
    } else { // Safety Emergency Exit
      return { x: k - 1.5, y: k - 2.0 };
    }
  } else if (presetKey === 'office') {
    const r = Math.random();
    if (r < 0.3) { // Board room
      return { x: 1 + Math.random() * 6, y: 1 + Math.random() * 5 };
    } else if (r < 0.75) { // Employee cubicles
      const row = Math.floor(Math.random() * 3);
      const side = Math.random() > 0.5 ? 10.3 : 13.8;
      return { x: side + Math.random() * 3.2, y: (1 + row * 5) + Math.random() * 3.5 };
    } else { // Cafeteria/Kitchen space
      return { x: 1 + Math.random() * 6, y: (k - 6) + Math.random() * 5 };
    }
  } else if (presetKey === 'subway') {
    const r = Math.random();
    if (r < 0.45) { // Top seating bench row
      return { x: 1 + Math.random() * (k - 2), y: 0.8 + Math.random() * 0.5 };
    } else if (r < 0.9) { // Bottom seating bench row
      return { x: 1 + Math.random() * (k - 2), y: k - 1.3 + Math.random() * 0.5 };
    } else { // Exit sliding pneumatic doors
      return { x: Math.random() > 0.5 ? 0.3 : k - 0.3, y: 2.5 + Math.random() * 2 };
    }
  } else if (presetKey === 'park') {
    const r = Math.random();
    if (r < 0.35) { // Main Concert stage area
      return { x: k / 2 - 2.5 + Math.random() * 5, y: 1.5 + Math.random() * 2.2 };
    } else if (r < 0.55) { // Food truck outpost
      return { x: 1.5 + Math.random() * 2.5, y: k - 4.5 + Math.random() * 1.5 };
    } else if (r < 0.75) { // Beer garden patio
      return { x: k - 4.5 + Math.random() * 3.5, y: k - 4.5 + Math.random() * 3.5 };
    } else { // Circular walkways / stroll paths
      const angle = Math.random() * Math.PI * 2;
      const radius = 3 + Math.random() * 4.5;
      return { x: k / 2 + Math.cos(angle) * radius, y: k / 2 + Math.sin(angle) * radius };
    }
  } else {
    // Normal open-air Community quadrants
    const r = Math.random();
    if (r < 0.25) { // Zone A
      return { x: 1.5 + Math.random() * 3, y: 1.5 + Math.random() * 3 };
    } else if (r < 0.5) { // Zone B
      return { x: k - 4.5 + Math.random() * 3, y: 1.5 + Math.random() * 3 };
    } else if (r < 0.75) { // Zone C
      return { x: 1.5 + Math.random() * 3, y: k - 4.5 + Math.random() * 3 };
    } else { // Zone D
      return { x: k - 4.5 + Math.random() * 3, y: k - 4.5 + Math.random() * 3 };
    }
  }
}

// Architectural Blueprint Layout Helpers
function drawSchoolBlueprint(ctx: CanvasRenderingContext2D, k: number, scale: number) {
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.22)';
  ctx.fillStyle = 'rgba(56, 189, 248, 0.03)';
  ctx.lineWidth = 1;
  ctx.strokeRect(0.2 * scale, 0.2 * scale, (k - 0.4) * scale, (k - 0.4) * scale);
  ctx.fillRect(0.2 * scale, 0.2 * scale, (k - 0.4) * scale, (k - 0.4) * scale);

  // Teacher Podium Desk
  ctx.strokeRect(3 * scale, 1.2 * scale, 4 * scale, 1.2 * scale);
  ctx.fillStyle = 'rgba(56, 189, 248, 0.08)';
  ctx.fillRect(3 * scale, 1.2 * scale, 4 * scale, 1.2 * scale);
  ctx.fillStyle = 'rgba(56, 189, 248, 0.55)';
  ctx.font = `bold ${Math.max(9, 0.35 * scale)}px sans-serif`;
  ctx.fillText("TEACHER DESK & GRAPHIC BOARD", 3.2 * scale, 0.8 * scale);

  // Student desks
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 3; c++) {
      const dx = (1.5 + c * 2.8) * scale;
      const dy = (3.5 + r * 1.5) * scale;
      const dw = 1.4 * scale;
      const dh = 0.7 * scale;
      ctx.strokeRect(dx, dy, dw, dh);
      ctx.fillStyle = 'rgba(56, 189, 248, 0.45)';
      ctx.fillText(`DESK ${r * 3 + c + 1}`, dx + 0.1 * scale, dy + 0.45 * scale);
      
      // Arc representing chair
      ctx.beginPath();
      ctx.arc(dx + dw / 2, dy + dh + 0.2 * scale, 0.15 * scale, Math.PI, 0);
      ctx.stroke();
    }
  }

  // Swinging escape safety door
  ctx.strokeStyle = 'rgba(239, 68, 68, 0.4)';
  ctx.beginPath();
  ctx.moveTo((k - 0.2) * scale, (k - 2) * scale);
  ctx.lineTo((k - 1.4) * scale, (k - 2) * scale);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc((k - 0.2) * scale, (k - 2) * scale, 1.2 * scale, Math.PI, Math.PI * 1.5);
  ctx.stroke();
  ctx.fillStyle = 'rgba(239, 68, 68, 0.6)';
  ctx.fillText("SAFETY EMERGENCY EXIT", (k - 5) * scale, (k - 2.2) * scale);
}

function drawOfficeBlueprint(ctx: CanvasRenderingContext2D, k: number, scale: number) {
  ctx.strokeStyle = 'rgba(129, 140, 248, 0.22)';
  ctx.fillStyle = 'rgba(129, 140, 248, 0.03)';
  ctx.lineWidth = 1;

  // Board Room
  ctx.strokeRect(0.5 * scale, 0.5 * scale, 7 * scale, 6 * scale);
  ctx.fillRect(0.5 * scale, 0.5 * scale, 7 * scale, 6 * scale);
  
  // Board room table
  ctx.beginPath();
  ctx.ellipse(4 * scale, 3.5 * scale, 2.0 * scale, 1.1 * scale, 0, 0, Math.PI * 2);
  ctx.stroke();
  ctx.fillStyle = 'rgba(129, 140, 248, 0.55)';
  ctx.font = `bold ${Math.max(9, 0.35 * scale)}px sans-serif`;
  ctx.fillText("CONFERENCE BOARD ROOM", 1.8 * scale, 1.2 * scale);

  // Executive Cubicles (Right)
  for (let r = 0; r < 3; r++) {
    const cy = (1 + r * 5) * scale;
    ctx.strokeRect(10 * scale, cy, 7 * scale, 4 * scale);
    ctx.strokeRect(10 * scale, cy, 3.5 * scale, 4 * scale);
    ctx.fillStyle = 'rgba(129, 140, 248, 0.45)';
    ctx.fillText(`CUBICLE ${r * 2 + 1}`, 10.3 * scale, cy + 1.2 * scale);
    ctx.fillText(`CUBICLE ${r * 2 + 2}`, 13.8 * scale, cy + 1.2 * scale);
  }

  // Break Area
  ctx.strokeRect(0.5 * scale, (k - 6.5) * scale, 7 * scale, 6 * scale);
  ctx.fillText("KITCHEN CAFÉ RETREAT", 1 * scale, (k - 5.2) * scale);
  ctx.strokeRect(0.5 * scale, (k - 2.5) * scale, 5 * scale, 2 * scale);
}

function drawSubwayBlueprint(ctx: CanvasRenderingContext2D, k: number, scale: number) {
  ctx.strokeStyle = 'rgba(234, 179, 8, 0.2)';
  ctx.fillStyle = 'rgba(234, 179, 8, 0.02)';
  ctx.lineWidth = 1.2;

  // Carriage border
  ctx.strokeRect(0.2 * scale, 0.5 * scale, (k - 0.4) * scale, (k - 1) * scale);
  ctx.fillRect(0.2 * scale, 0.5 * scale, (k - 0.4) * scale, (k - 1) * scale);

  // Bench seating rows (top and bottom)
  ctx.strokeRect(0.5 * scale, 0.6 * scale, (k - 1) * scale, 1.0 * scale);
  ctx.strokeRect(0.5 * scale, (k - 1.6) * scale, (k - 1) * scale, 1.0 * scale);

  // Dividers for individual seat units
  ctx.beginPath();
  for (let x = 1.0; x < k - 1.0; x += 0.8) {
    ctx.moveTo(x * scale, 0.6 * scale);
    ctx.lineTo(x * scale, 1.6 * scale);
    ctx.moveTo(x * scale, (k - 1.6) * scale);
    ctx.lineTo(x * scale, (k - 0.6) * scale);
  }
  ctx.stroke();

  // Highlight sliding pneumatic doors
  ctx.strokeStyle = 'rgba(234, 179, 8, 0.55)';
  ctx.lineWidth = 3.2;
  ctx.beginPath();
  ctx.moveTo(0.2 * scale, 2.5 * scale);
  ctx.lineTo(0.2 * scale, 4.5 * scale);
  ctx.moveTo((k - 0.2) * scale, 2.5 * scale);
  ctx.lineTo((k - 0.2) * scale, 4.5 * scale);
  ctx.stroke();

  ctx.fillStyle = 'rgba(234, 179, 8, 0.55)';
  ctx.font = `bold ${Math.max(9, 0.35 * scale)}px sans-serif`;
  ctx.fillText("METROPOLITAN TRAIN - CAR #1024", 1.2 * scale, (k / 2) * scale);
  ctx.fillText("DOOR 1L", 0.4 * scale, 2.2 * scale);
  ctx.fillText("DOOR 1R", (k - 1.6) * scale, 2.2 * scale);
}

function drawParkBlueprint(ctx: CanvasRenderingContext2D, k: number, scale: number) {
  ctx.strokeStyle = 'rgba(34, 197, 94, 0.22)';
  ctx.fillStyle = 'rgba(34, 197, 94, 0.03)';
  ctx.lineWidth = 1;

  // Circular pathways
  ctx.beginPath();
  ctx.arc((k / 2) * scale, (k / 2) * scale, 3.5 * scale, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc((k / 2) * scale, (k / 2) * scale, 7.5 * scale, 0, Math.PI * 2);
  ctx.stroke();

  // Grand stage
  const sw = 6 * scale;
  const sh = 2.8 * scale;
  const sx = (k / 2 - 3) * scale;
  const sy = 1.2 * scale;
  ctx.strokeRect(sx, sy, sw, sh);
  ctx.fillRect(sx, sy, sw, sh);

  ctx.fillStyle = 'rgba(34, 197, 94, 0.55)';
  ctx.font = `bold ${Math.max(9, 0.38 * scale)}px sans-serif`;
  ctx.fillText("LIVE MUSIC FESTIVAL STAGE", sx + 1.2 * scale, sy + 1.6 * scale);

  // Outpost stands
  ctx.strokeRect(1 * scale, (k - 5) * scale, 3.5 * scale, 1.8 * scale);
  ctx.fillText("PREMIUM FOOD TRUCK", 1.2 * scale, (k - 3.8) * scale);

  ctx.strokeRect((k - 5) * scale, (k - 5) * scale, 4 * scale, 4 * scale);
  ctx.fillText("BEER GARDEN", (k - 4.5) * scale, (k - 2.8) * scale);

  // Trees botanical outlines
  const parkTrees = [{x: 2, y: 5}, {x: k - 3, y: 7}, {x: 3, y: k - 9}];
  parkTrees.forEach(t => {
    ctx.beginPath();
    ctx.arc(t.x * scale, t.y * scale, 0.7 * scale, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(t.x * scale, t.y * scale, 0.35 * scale, 0, Math.PI * 2);
    ctx.stroke();
  });
}

function drawNormalBlueprint(ctx: CanvasRenderingContext2D, k: number, scale: number) {
  ctx.strokeStyle = 'rgba(6, 182, 212, 0.18)';
  ctx.fillStyle = 'rgba(6, 182, 212, 0.02)';
  ctx.lineWidth = 1;

  ctx.beginPath();
  ctx.arc((k / 2) * scale, (k / 2) * scale, 2.2 * scale, 0, Math.PI * 2);
  ctx.stroke();
  ctx.fillStyle = 'rgba(6, 182, 212, 0.5)';
  ctx.font = `bold ${Math.max(9, 0.35 * scale)}px sans-serif`;
  ctx.fillText("COMMUNITY CENTRAL SQUAREPlaza", (k / 2 - 2 * scale), (k / 2 + 0.1) * scale);

  // Grid Boulevard lanes
  ctx.strokeRect(0, (k / 2 - 0.8) * scale, k * scale, 1.6 * scale);
  ctx.strokeRect((k / 2 - 0.8) * scale, 0, 1.6 * scale, k * scale);

  // Residential complexes
  ctx.strokeRect(1 * scale, 1 * scale, 4 * scale, 4 * scale);
  ctx.fillText("RESIDENTIAL ZONE A", 1.2 * scale, 2.2 * scale);

  ctx.strokeRect((k - 5) * scale, 1 * scale, 4 * scale, 4 * scale);
  ctx.fillText("MEDICAL DISTRICT B", (k - 4.8) * scale, 2.2 * scale);

  ctx.strokeRect(1 * scale, (k - 5) * scale, 4 * scale, 4 * scale);
  ctx.fillText("PUBLIC GREEN PARKWAY", 1.2 * scale, (k - 2.8) * scale);

  ctx.strokeRect((k - 5) * scale, (k - 5) * scale, 4 * scale, 4 * scale);
  ctx.fillText("HYPERMARKET STORES", (k - 4.8) * scale, (k - 2.8) * scale);
}

function drawHospitalBlueprint(ctx: CanvasRenderingContext2D, k: number, scale: number, doorsClosed: boolean) {
  ctx.strokeStyle = 'rgba(239, 68, 68, 0.22)';
  ctx.fillStyle = 'rgba(239, 68, 68, 0.03)';
  ctx.lineWidth = 1;

  const mid = k / 2;
  const doorSize = 1.2;

  // Draw 4 isolated quarantine rooms
  ctx.strokeRect(0.2 * scale, 0.2 * scale, (mid - 0.2) * scale, (mid - 0.2) * scale);
  ctx.fillRect(0.2 * scale, 0.2 * scale, (mid - 0.2) * scale, (mid - 0.2) * scale);

  ctx.strokeRect((mid + 0.0) * scale, 0.2 * scale, (mid - 0.2) * scale, (mid - 0.2) * scale);
  ctx.fillRect((mid + 0.0) * scale, 0.2 * scale, (mid - 0.2) * scale, (mid - 0.2) * scale);

  ctx.strokeRect(0.2 * scale, (mid + 0.0) * scale, (mid - 0.2) * scale, (mid - 0.2) * scale);
  ctx.fillRect(0.2 * scale, (mid + 0.0) * scale, (mid - 0.2) * scale, (mid - 0.2) * scale);

  ctx.strokeRect((mid + 0.0) * scale, (mid + 0.0) * scale, (mid - 0.2) * scale, (mid - 0.2) * scale);
  ctx.fillRect((mid + 0.0) * scale, (mid + 0.0) * scale, (mid - 0.2) * scale, (mid - 0.2) * scale);

  // Central Nurse Station circle
  ctx.beginPath();
  ctx.arc(mid * scale, mid * scale, 1.4 * scale, 0, Math.PI * 2);
  ctx.strokeStyle = 'rgba(239, 68, 68, 0.45)';
  ctx.stroke();
  ctx.fillStyle = 'rgba(239, 68, 68, 0.08)';
  ctx.fill();

  ctx.fillStyle = 'rgba(239, 68, 68, 0.6)';
  ctx.font = `bold ${Math.max(9, 0.35 * scale)}px sans-serif`;
  ctx.fillText("NURSE STATION", (mid - 1.2) * scale, (mid + 0.1) * scale);

  // Bed and ward labels
  const labels = [
    { text: "WARD A (격리실 A)", x: 0.8, y: 1.2 },
    { text: "WARD B (격리실 B)", x: mid + 0.8, y: 1.2 },
    { text: "WARD C (격리실 C)", x: 0.8, y: mid + 1.2 },
    { text: "WARD D (격리실 D)", x: mid + 0.8, y: mid + 1.2 }
  ];

  labels.forEach(l => {
    ctx.fillStyle = 'rgba(239, 68, 68, 0.55)';
    ctx.fillText(l.text, l.x * scale, l.y * scale);
    
    // Hospital bed blueprint sketch
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.2)';
    ctx.strokeRect((l.x + 0.2) * scale, (l.y + 0.4) * scale, 1.8 * scale, 1.0 * scale);
    ctx.strokeRect((l.x + 0.3) * scale, (l.y + 0.5) * scale, 0.4 * scale, 0.8 * scale); // pillow
  });
}

function drawPhysicsWalls(ctx: CanvasRenderingContext2D, k: number, scale: number, presetKey: string, doorsClosed: boolean) {
  const allWalls = getPresetWalls(presetKey, k, true);

  ctx.save();
  for (const wall of allWalls) {
    if (wall.isDoor) {
      const x_mid = (wall.x1 + wall.x2) / 2;
      const y_mid = (wall.y1 + wall.y2) / 2;

      if (doorsClosed) {
        // Draw CLOSED sliding doors (tactile red glowing bar)
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.95)';
        ctx.lineWidth = 6;
        ctx.lineCap = 'square';
        ctx.beginPath();
        ctx.moveTo(wall.x1 * scale, wall.y1 * scale);
        ctx.lineTo(wall.x2 * scale, wall.y2 * scale);
        ctx.stroke();

        // Locked dot signal
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.arc(x_mid * scale, y_mid * scale, 3.5, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#fca5a5';
        ctx.font = `bold ${Math.max(6.5, 0.22 * scale)}px sans-serif`;
        const text = wall.doorName || "DOOR";
        if (wall.horizontal) {
          ctx.fillText("🔒 " + text, (x_mid - 0.75) * scale, (y_mid - 0.2) * scale);
        } else {
          ctx.fillText("🔒 " + text, (x_mid + 0.15) * scale, (y_mid - 0.1) * scale);
        }
      } else {
        // Draw OPEN doors (dashed footprint pathway + sliding split door panels at edges)
        ctx.strokeStyle = 'rgba(52, 211, 153, 0.45)';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.moveTo(wall.x1 * scale, wall.y1 * scale);
        ctx.lineTo(wall.x2 * scale, wall.y2 * scale);
        ctx.stroke();
        ctx.setLineDash([]);

        // Slid panels retract 22% towards outer wall edges
        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 5.5;
        ctx.lineCap = 'round';
        const len = wall.horizontal ? (wall.x2 - wall.x1) : (wall.y2 - wall.y1);
        const pSize = len * 0.22;

        if (wall.horizontal) {
          ctx.beginPath();
          ctx.moveTo(wall.x1 * scale, wall.y1 * scale);
          ctx.lineTo((wall.x1 + pSize) * scale, wall.y1 * scale);
          ctx.moveTo((wall.x2 - pSize) * scale, wall.y1 * scale);
          ctx.lineTo(wall.x2 * scale, wall.y1 * scale);
          ctx.stroke();

          ctx.fillStyle = '#34d399';
          ctx.font = `bold ${Math.max(6.5, 0.22 * scale)}px sans-serif`;
          ctx.fillText("🔓 OPEN", (x_mid - 0.35) * scale, (y_mid - 0.2) * scale);
        } else {
          ctx.beginPath();
          ctx.moveTo(wall.x1 * scale, wall.y1 * scale);
          ctx.lineTo(wall.x1 * scale, (wall.y1 + pSize) * scale);
          ctx.moveTo(wall.x2 * scale, (wall.y2 - pSize) * scale);
          ctx.lineTo(wall.x1 * scale, wall.y2 * scale);
          ctx.stroke();

          ctx.fillStyle = '#34d399';
          ctx.font = `bold ${Math.max(6.5, 0.22 * scale)}px sans-serif`;
          ctx.fillText("🔓 OPEN", (x_mid + 0.15) * scale, (y_mid - 0.1) * scale);
        }
      }
    } else {
      // Draw regular solid physical masonry with double borders
      ctx.strokeStyle = 'rgba(31, 41, 55, 0.9)'; // Charcoal shadow boundary
      ctx.lineWidth = 6;
      ctx.beginPath();
      ctx.moveTo(wall.x1 * scale, wall.y1 * scale);
      ctx.lineTo(wall.x2 * scale, wall.y2 * scale);
      ctx.stroke();

      ctx.strokeStyle = '#94a3b8'; // Slate core wall lines
      ctx.lineWidth = 3.2;
      ctx.beginPath();
      ctx.moveTo(wall.x1 * scale, wall.y1 * scale);
      ctx.lineTo(wall.x2 * scale, wall.y2 * scale);
      ctx.stroke();
    }
  }
  ctx.restore();
}

function drawBuildingBlueprint(ctx: CanvasRenderingContext2D, k: number, scale: number, presetKey: string, doorsClosed: boolean) {
  ctx.save();
  if (presetKey === 'school') {
    drawSchoolBlueprint(ctx, k, scale);
  } else if (presetKey === 'office') {
    drawOfficeBlueprint(ctx, k, scale);
  } else if (presetKey === 'subway') {
    drawSubwayBlueprint(ctx, k, scale);
  } else if (presetKey === 'park') {
    drawParkBlueprint(ctx, k, scale);
  } else if (presetKey === 'hospital') {
    drawHospitalBlueprint(ctx, k, scale, doorsClosed);
  } else {
    drawNormalBlueprint(ctx, k, scale);
  }
  ctx.restore();

  // Overlay solid real active walls and sliding doors visibly on top of the blueprint layout!
  drawPhysicsWalls(ctx, k, scale, presetKey, doorsClosed);
}

function getCoverageColor(coverage: number, maxOpacity: number = 0.35): string {
  // coverage: 0.0 to 1.0
  // Segments:
  // 0.0 -> Warm Crimson/Red (239, 68, 68) indicating extreme vulnerability
  // 0.3 -> Orange/Amber (245, 158, 11)
  // 0.7 -> Teal/Cyan (6, 182, 212)
  // 1.0 -> Emerald Green (16, 185, 129)
  
  let r = 0, g = 0, b = 0;
  if (coverage <= 0.3) {
    const t = coverage / 0.3;
    r = Math.round(239 + (245 - 239) * t);
    g = Math.round(68 + (158 - 68) * t);
    b = Math.round(68 + (11 - 68) * t);
  } else if (coverage <= 0.7) {
    const t = (coverage - 0.3) / 0.4;
    r = Math.round(245 + (6 - 245) * t);
    g = Math.round(158 + (182 - 158) * t);
    b = Math.round(11 + (212 - 11) * t);
  } else {
    const t = (coverage - 0.7) / 0.3;
    r = Math.round(6 + (16 - 6) * t);
    g = Math.round(182 + (185 - 182) * t);
    b = Math.round(212 + (129 - 212) * t);
  }

  const alpha = 0.08 + coverage * (maxOpacity - 0.08);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function drawVaccineHeatmap(
  ctx: CanvasRenderingContext2D,
  balls: Ball[],
  k: number,
  canvasWidth: number,
  canvasHeight: number,
  mode: 'smooth' | 'grid' | 'off'
) {
  if (mode === 'off') return;

  const GRID_SIZE = mode === 'smooth' ? 16 : 8;
  const tileWidth = canvasWidth / GRID_SIZE;
  const tileHeight = canvasHeight / GRID_SIZE;

  // Bandwidth radius of influence (in simulation units)
  const R = k / 3.2; 

  for (let r = 0; r < GRID_SIZE; r++) {
    for (let c = 0; c < GRID_SIZE; c++) {
      const cx = (c + 0.5) * (k / GRID_SIZE);
      const cy = (r + 0.5) * (k / GRID_SIZE);

      let weightedVaccinated = 0;
      let weightedTotal = 0;
      let rawVaccinatedCount = 0;
      let rawAliveCount = 0;

      balls.forEach(ball => {
        if (ball.status === Status.DEAD) return; // Ignore dead agents
        
        const dx = ball.x - cx;
        const dy = ball.y - cy;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (mode === 'grid') {
          const bCol = Math.floor(ball.x / (k / GRID_SIZE));
          const bRow = Math.floor(ball.y / (k / GRID_SIZE));
          if (bCol === c && bRow === r) {
            rawAliveCount++;
            if (ball.isVaccinated) {
              rawVaccinatedCount++;
            }
          }
        } else {
          if (dist < R) {
            const w = 1 - (dist / R); // Linear decay weight
            weightedTotal += w;
            if (ball.isVaccinated) {
              weightedVaccinated += w;
            }
          }
        }
      });

      let coverage = 0;
      let shouldDraw = false;

      if (mode === 'grid') {
        coverage = rawAliveCount > 0 ? (rawVaccinatedCount / rawAliveCount) : 0;
        shouldDraw = rawAliveCount > 0;
      } else {
        coverage = weightedTotal > 0 ? (weightedVaccinated / weightedTotal) : 0;
        shouldDraw = weightedTotal > 0.05;
      }

      if (shouldDraw) {
        ctx.save();
        const colorStr = getCoverageColor(coverage, mode === 'grid' ? 0.45 : 0.35);
        ctx.fillStyle = colorStr;

        if (mode === 'grid') {
          const gap = 1.0;
          const x = c * tileWidth + gap;
          const y = r * tileHeight + gap;
          const w = tileWidth - gap * 2;
          const h = tileHeight - gap * 2;
          
          ctx.beginPath();
          ctx.rect(x, y, w, h);
          ctx.fill();

          ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
          ctx.font = 'bold 8px monospace';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(`${Math.round(coverage * 100)}%`, x + w / 2, y + h / 2);
        } else {
          ctx.beginPath();
          ctx.rect(c * tileWidth, r * tileHeight, tileWidth, tileHeight);
          ctx.fill();
        }

        ctx.restore();
      }
    }
  }
}

function getDiseaseColor(id: number, diseaseTabs?: any[]): string {
  const colors = ['#ef4444', '#a855f7', '#f59e0b', '#06b6d4', '#ec4899'];
  if (diseaseTabs && Array.isArray(diseaseTabs)) {
    const idx = diseaseTabs.findIndex(t => t.id === id);
    if (idx !== -1) return colors[idx % colors.length];
  }
  switch (id) {
    case 1: return '#ef4444'; // Red
    case 2: return '#f59e0b'; // Amber/Orange
    case 3: return '#a855f7'; // Purple
    case 4: return '#06b6d4'; // Cyan
    case 5: return '#ec4899'; // Hot Pink
    default: return colors[Math.floor(id) % colors.length] || '#fb7185';
  }
}

function syncBallTopLevelState(ball: Ball, activeDiseaseIds: number[]) {
  if (ball.status === Status.DEAD) return;
  
  if (!ball.diseaseStates) {
    return;
  }
  
  let hasInfected = false;
  let hasRecovered = false;
  let maxImmunityTime = 0;
  let totalInfectionsCount = 0;
  let earliestInfectedAt: number | undefined = undefined;
  
  activeDiseaseIds.forEach(dId => {
    const ds = ball.diseaseStates?.[dId];
    if (ds) {
      if (ds.status === Status.INFECTED) {
        hasInfected = true;
        if (earliestInfectedAt === undefined || (ds.infectedAt !== undefined && ds.infectedAt < earliestInfectedAt)) {
          earliestInfectedAt = ds.infectedAt;
        }
      } else if (ds.status === Status.RECOVERED) {
        hasRecovered = true;
        if (ds.immunityTimeRemaining > maxImmunityTime) {
          maxImmunityTime = ds.immunityTimeRemaining;
        }
      }
      totalInfectionsCount += ds.infectionsCount || 0;
    }
  });
  
  if (hasInfected) {
    ball.status = Status.INFECTED;
    ball.infectedAt = earliestInfectedAt;
  } else if (hasRecovered) {
    ball.status = Status.RECOVERED;
    ball.immunityTimeRemaining = maxImmunityTime;
  } else {
    ball.status = Status.SUSCEPTIBLE;
    ball.immunityTimeRemaining = 0;
  }
  ball.infectionsCount = totalInfectionsCount;
}

function drawSingleBall(
  ctx: CanvasRenderingContext2D,
  ball: Ball,
  scale: number,
  activeDiseaseIds: number[],
  diseaseTabs: any[],
  transmissionProb: number
) {
  if (ball.status === Status.DEAD && ball.opacity <= 0) return;

  ctx.save();
  ctx.globalAlpha = ball.opacity;
  const radius = OBJECT_RADIUS * scale;

  if (ball.status === Status.INFECTED) {
    const activeInfections = activeDiseaseIds.filter(dId => {
      return ball.diseaseStates?.[dId]?.status === Status.INFECTED;
    });

    if (activeInfections.length > 0) {
      const numInfections = activeInfections.length;
      for (let idx = 0; idx < numInfections; idx++) {
        const startAngle = (idx * 2 * Math.PI) / numInfections - Math.PI / 2;
        const endAngle = ((idx + 1) * 2 * Math.PI) / numInfections - Math.PI / 2;
        
        ctx.beginPath();
        ctx.moveTo(ball.x * scale, ball.y * scale);
        ctx.arc(ball.x * scale, ball.y * scale, radius, startAngle, endAngle);
        ctx.closePath();
        ctx.fillStyle = getDiseaseColor(activeInfections[idx], diseaseTabs);
        ctx.fill();
      }
      
      ctx.shadowColor = getDiseaseColor(activeInfections[0], diseaseTabs);
      ctx.shadowBlur = 8 * ball.opacity;
    } else {
      ctx.beginPath();
      ctx.arc(ball.x * scale, ball.y * scale, radius, 0, Math.PI * 2);
      ctx.fillStyle = '#ef4444';
      ctx.shadowColor = '#fca5a5';
      ctx.shadowBlur = 8 * ball.opacity;
      ctx.fill();
    }
  } else if (ball.status === Status.RECOVERED) {
    ctx.beginPath();
    ctx.arc(ball.x * scale, ball.y * scale, radius, 0, Math.PI * 2);
    ctx.fillStyle = '#10b981';
    ctx.fill();
  } else if (ball.status === Status.DEAD) {
    ctx.beginPath();
    ctx.arc(ball.x * scale, ball.y * scale, radius, 0, Math.PI * 2);
    ctx.fillStyle = '#9ca3af';
    ctx.fill();
  } else {
    ctx.beginPath();
    ctx.arc(ball.x * scale, ball.y * scale, radius, 0, Math.PI * 2);
    ctx.fillStyle = '#3b82f6';
    ctx.fill();
  }

  ctx.shadowBlur = 0;
  ctx.beginPath();
  ctx.arc(ball.x * scale, ball.y * scale, radius, 0, Math.PI * 2);
  ctx.strokeStyle = ball.isMoving ? '#ffffff' : 'rgba(255,255,255,0.3)';
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.restore();
}

export default function App() {
  // Configurable Parameters (With broadened ranges)
  const [k, setK] = useState(15);
  const [n, setN] = useState(45);
  const [transmissionProb, setTransmissionProb] = useState(40); // default to Covid-19 values (Tab 2)
  const [naturalDeathRate, setNaturalDeathRate] = useState(0.08); // % per sec
  const [birthRate, setBirthRate] = useState(0.15); // % per sec
  const [infectionDeathRate, setInfectionDeathRate] = useState(0.3); // % dying while infected per sec
  const [recoveryRate, setRecoveryRate] = useState(15); // % recovering while infected per sec
  const [immunityDuration, setImmunityDuration] = useState(25); // seconds
  const [vaccinationRate, setVaccinationRate] = useState(30); // % of population vaccinated initially (starting as Recovered)
  const [initialInfectedCount, setInitialInfectedCount] = useState(2); // Initial active patients numbers
  const [speed, setSpeed] = useState(6);
  const [decisionIntervalMs, setDecisionIntervalMs] = useState(100); // Super-fine 100ms default for realistic path curves

  // Social Distancing and Multi-Disease Exploration states
  const [socialDistancing, setSocialDistancing] = useState<boolean>(false);
  const [heatmapMode, setHeatmapMode] = useState<'smooth' | 'grid' | 'off'>('off');

  interface DiseaseExplorerTab {
    id: number;
    name: string;
    transmissionProb: number;
    recoveryRate: number;
    infectionDeathRate: number;
    immunityDuration: number;
    r0: string;
    ifr: string;
    duration: string;
    desc: string;
    presetKey: string;
  }

  const DISEASE_PRESETS = [
    {
      key: "measles",
      name: "홍역 (Measles)",
      transmissionProb: 98,
      recoveryRate: 8,
      infectionDeathRate: 0.012,
      immunityDuration: 40,
      r0: "12.0 ~ 18.0",
      ifr: "0.1% ~ 0.2%",
      duration: "10 ~ 14일",
      desc: "공기 중 전파력이 가장 강력한 질환 중 하나로, 집단 면역 역치가 매우 높음(95% 이상)."
    },
    {
      key: "covid19",
      name: "코로나19 (COVID-19)",
      transmissionProb: 40,
      recoveryRate: 15,
      infectionDeathRate: 0.3,
      immunityDuration: 25,
      r0: "2.5 ~ 5.0",
      ifr: "1.0% ~ 2.0%",
      duration: "10 ~ 14일",
      desc: "높은 무증상 전파 및 빠른 호흡기 복제로 인해 글로벌 대유행을 초래한 대표 전염병."
    },
    {
      key: "mers",
      name: "메르스 (MERS)",
      transmissionProb: 15,
      recoveryRate: 14,
      infectionDeathRate: 7.0,
      immunityDuration: 25,
      r0: "0.4 ~ 0.9",
      ifr: "30.0% ~ 35.0%",
      duration: "10 ~ 14일",
      desc: "치명률이 매우 강하나 보건 환경 내 밀접 접촉 외 일반적인 공공 전파력은 상대적으로 낮음."
    },
    {
      key: "flu",
      name: "계절성 독감 (Influenza)",
      transmissionProb: 16,
      recoveryRate: 25,
      infectionDeathRate: 0.02,
      immunityDuration: 15,
      r0: "1.3 ~ 1.8",
      ifr: "0.1% 미만",
      duration: "3 ~ 7일",
      desc: "주기적인 항원 소변이로 인해 매년 전파되나 인플루엔자 백신과 타미플루 등이 존재."
    },
    {
      key: "ebola",
      name: "에볼라 (Ebola)",
      transmissionProb: 25,
      recoveryRate: 10,
      infectionDeathRate: 20.0,
      immunityDuration: 15,
      r0: "1.5 ~ 2.5",
      ifr: "40.0% ~ 50.0%",
      duration: "2 ~ 21일",
      desc: "밀접 접촉을 통해 전파되며 극도로 높은 치명률을 보이는 급성 바이러스성 열병."
    },
    {
      key: "custom",
      name: "가상 신종 바이러스 X",
      transmissionProb: 35,
      recoveryRate: 15,
      infectionDeathRate: 1.5,
      immunityDuration: 20,
      r0: "사용자 설정",
      ifr: "사용자 설정",
      duration: "사용자 설정",
      desc: "직접 매개변수를 설계하고 다른 탭의 실제 감염병들과 비교 및 대조할 수 있는 커스텀 감염병 연구 개체입니다."
    }
  ];

  const [diseaseTabs, setDiseaseTabs] = useState<DiseaseExplorerTab[]>([
    {
      id: 2,
      name: "코로나19",
      transmissionProb: 40,
      recoveryRate: 15,
      infectionDeathRate: 0.3,
      immunityDuration: 25,
      r0: "2.5 ~ 5.0",
      ifr: "1.0% ~ 2.0%",
      duration: "10 ~ 14일",
      desc: "높은 무증상 전파 및 빠른 호흡기 복제로 인해 글로벌 대유행을 초래한 대표 전염병.",
      presetKey: "covid19"
    },
    {
      id: 4,
      name: "독감",
      transmissionProb: 16,
      recoveryRate: 25,
      infectionDeathRate: 0.02,
      immunityDuration: 15,
      r0: "1.3 ~ 1.8",
      ifr: "0.1% 미만",
      duration: "3 ~ 7일",
      desc: "주기적인 항원 소변이로 인해 매년 전파되나 인플루엔자 백신과 타미플루 등이 존재.",
      presetKey: "flu"
    }
  ]);

  const [editingTabId, setEditingTabId] = useState<number>(2);
  const [activeSimTabId, setActiveSimTabId] = useState<number>(2); // Backwards compatibility placeholder

  const activeDiseaseIds = useMemo(() => {
    return diseaseTabs.map(t => t.id);
  }, [diseaseTabs]);

  const updateEditingTabParam = (
    field: "transmissionProb" | "recoveryRate" | "infectionDeathRate" | "immunityDuration",
    value: number
  ) => {
    setDiseaseTabs(prev => prev.map(tab => {
      if (tab.id === editingTabId) {
        return {
          ...tab,
          [field]: value,
          presetKey: "custom",
          r0: "사용자 설정",
          ifr: "사용자 설정",
          duration: "사용자 설정",
          desc: "매개변수를 조정한 사용자 정의 연구용 감염병입니다."
        };
      }
      return tab;
    }));
  };

  const updateEditingTabName = (name: string) => {
    setDiseaseTabs(prev => prev.map(tab => {
      if (tab.id === editingTabId) {
        return { ...tab, name };
      }
      return tab;
    }));
  };

  const applyPresetToEditingTab = (presetKey: string) => {
    const preset = DISEASE_PRESETS.find(p => p.key === presetKey);
    if (!preset) return;
    setDiseaseTabs(prev => prev.map(tab => {
      if (tab.id === editingTabId) {
        return {
          ...tab,
          name: presetKey === "custom" ? "신종 바이러스 X" : preset.name.split(" ")[0],
          transmissionProb: preset.transmissionProb,
          recoveryRate: preset.recoveryRate,
          infectionDeathRate: preset.infectionDeathRate,
          immunityDuration: preset.immunityDuration,
          r0: preset.r0,
          ifr: preset.ifr,
          duration: preset.duration,
          desc: preset.desc,
          presetKey: preset.key
        };
      }
      return tab;
    }));
  };

  const addNewTab = () => {
    const newId = Date.now();
    const newTab: DiseaseExplorerTab = {
      id: newId,
      name: `신종 질병 ${diseaseTabs.length + 1}`,
      transmissionProb: 30,
      recoveryRate: 15,
      infectionDeathRate: 1.0,
      immunityDuration: 20,
      r0: "사용자 설정",
      ifr: "사용자 설정",
      duration: "사용자 설정",
      desc: "새로 생성된 사용자 정의 연구용 감염병 개체입니다.",
      presetKey: "custom"
    };
    setDiseaseTabs(prev => [...prev, newTab]);
    setEditingTabId(newId);
  };

  const removeTab = (idToRemove: number, e: React.MouseEvent) => {
    e.stopPropagation();
    if (diseaseTabs.length <= 1) return;
    setDiseaseTabs(prev => {
      const filtered = prev.filter(tab => tab.id !== idToRemove);
      if (editingTabId === idToRemove) {
        setEditingTabId(filtered[0].id);
      }
      return filtered;
    });
  };

  // App & Panel States
  const [activePreset, setActivePreset] = useState<string>("normal");
  const [simSpeed, setSimSpeed] = useState<number>(1.0);
  const [isRunning, setIsRunning] = useState(false);
  const [objectCollisions, setObjectCollisions] = useState(0);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [history, setHistory] = useState<HistoryData[]>([]);
  const [balls, setBalls] = useState<Ball[]>([]);
  const [isPythonModalOpen, setIsPythonModalOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const [doorsClosed, setDoorsClosed] = useState<boolean>(true);
  const [useIntention, setUseIntention] = useState<boolean>(true);
  const [steeringSpeed, setSteeringSpeed] = useState<number>(30); // Dynamic steering response (30%)
  const [enableBallCollision, setEnableBallCollision] = useState<boolean>(true); // Elastic inter-agent bouncing
  const [enableWiggle, setEnableWiggle] = useState<boolean>(true); // Lifelike sways and Brownian wiggles
  const [slideAlongWalls, setSlideAlongWalls] = useState<boolean>(true); // Slither along borders/colliders

  // Keyboard shortcut listener for Door Quick Toggle: Press 'D' or 'd' to instantly lock/unlock
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (
        document.activeElement?.tagName === 'INPUT' || 
        document.activeElement?.tagName === 'TEXTAREA' || 
        target?.isContentEditable
      ) {
        return;
      }
      if (e.key === 'd' || e.key === 'D' || e.key === 'ㅇ') {
        setDoorsClosed(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const [empiricalStats, setEmpiricalStats] = useState<EmpiricalStats>({
    completedCount: 0,
    totalSecondaryInfections: 0,
    totalDuration: 0,
    diseaseDeaths: 0,
    recoveries: 0
  });

  const empiricalStatsRef = useRef<EmpiricalStats>({
    completedCount: 0,
    totalSecondaryInfections: 0,
    totalDuration: 0,
    diseaseDeaths: 0,
    recoveries: 0
  });

  const activeWalls = useMemo(() => {
    return getPresetWalls(activePreset, k, doorsClosed);
  }, [activePreset, k, doorsClosed]);


  // Empirical calculations
  const empiricalR0Val = useMemo(() => {
    if (empiricalStats.completedCount === 0) return 0;
    return empiricalStats.totalSecondaryInfections / empiricalStats.completedCount;
  }, [empiricalStats]);

  const empiricalIFRVal = useMemo(() => {
    const d = empiricalStats.diseaseDeaths;
    const r = empiricalStats.recoveries;
    if (d + r === 0) return 0;
    return (d / (d + r)) * 100;
  }, [empiricalStats]);

  const empiricalDurationVal = useMemo(() => {
    if (empiricalStats.completedCount === 0) return 0;
    return empiricalStats.totalDuration / empiricalStats.completedCount;
  }, [empiricalStats]);

  // Refs for physics loop
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const lastUpdateRef = useRef<number>(0);
  const lastDecisionRef = useRef<number>(0);
  const lastHistoryRef = useRef<number>(0);
  const simAccumulatorRef = useRef<number>(0);
  const ballsRef = useRef<Ball[]>([]);
  const activeCollisionsRef = useRef<Set<string>>(new Set());
  const elapsedTimeRef = useRef<number>(0);

  // Function to apply a preset environment
  const applyPreset = useCallback((presetKey: string) => {
    const p = PRESETS[presetKey];
    if (!p) return;
    setActivePreset(presetKey);
    setK(p.k);
    setN(p.n);
    setTransmissionProb(p.transmissionProb);
    setBirthRate(p.birthRate);
    setNaturalDeathRate(p.naturalDeathRate);
    setInfectionDeathRate(p.infectionDeathRate);
    setRecoveryRate(p.recoveryRate);
    setSpeed(p.speed);
    setDecisionIntervalMs(p.decisionInterval);
    setIsRunning(false);
  }, []);

  // Initialize objects
  const initBalls = useCallback(() => {
    const newBalls: Ball[] = [];
    const margin = OBJECT_RADIUS + 0.1;
    const currentWalls = getPresetWalls(activePreset, k, doorsClosed);

    // Pre-calculate infected indices per active disease
    const diseaseInfectedIndices: { [dId: number]: Set<number> } = {};
    activeDiseaseIds.forEach(dId => {
      const infectedSet = new Set<number>();
      const countToInfect = Math.min(initialInfectedCount, n);
      while (infectedSet.size < countToInfect) {
        infectedSet.add(Math.floor(Math.random() * n));
      }
      diseaseInfectedIndices[dId] = infectedSet;
    });

    for (let i = 0; i < n; i++) {
      let x = 0;
      let y = 0;
      let overlap = false;
      let attempts = 0;

      do {
        overlap = false;
        x = margin + Math.random() * (k - 2 * margin);
        y = margin + Math.random() * (k - 2 * margin);
        
        // Push the testing ball out of wall segment space so it doesn't spawn clipped inside walls
        const tempBall: Ball = {
          id: i,
          x,
          y,
          vx: 0,
          vy: 0,
          isMoving: false,
          status: Status.SUSCEPTIBLE,
          immunityTimeRemaining: 0,
          opacity: 1.0
        };
        resolveWallCollisions(tempBall, currentWalls);
        x = tempBall.x;
        y = tempBall.y;

        for (const other of newBalls) {
          const dx = x - other.x;
          const dy = y - other.y;
          if (Math.sqrt(dx * dx + dy * dy) < OBJECT_DIAMETER) {
            overlap = true;
            break;
          }
        }
        attempts++;
      } while (overlap && attempts < 150);

      const diseaseStates: { [diseaseId: number]: BallDiseaseState } = {};
      
      // Initialize states for all 5 possible diseases, to be fully safe
      diseaseTabs.forEach(tab => {
        const dId = tab.id;
        const isActive = activeDiseaseIds.includes(dId);
        
        if (isActive) {
          const infectedSet = diseaseInfectedIndices[dId];
          const isLInfected = infectedSet && infectedSet.has(i);
          const roll = Math.random() * 100;
          const isLVaccinated = !isLInfected && (roll < vaccinationRate);
          
          let dStatus = Status.SUSCEPTIBLE;
          if (isLInfected) {
            dStatus = Status.INFECTED;
          } else if (isLVaccinated) {
            dStatus = Status.RECOVERED;
          }
          
          diseaseStates[dId] = {
            status: dStatus,
            immunityTimeRemaining: dStatus === Status.RECOVERED ? Math.random() * tab.immunityDuration : 0,
            infectedAt: dStatus === Status.INFECTED ? 0 : undefined,
            infectionsCount: 0
          };
        } else {
          diseaseStates[dId] = {
            status: Status.SUSCEPTIBLE,
            immunityTimeRemaining: 0,
            infectedAt: undefined,
            infectionsCount: 0
          };
        }
      });

      const hasInfected = activeDiseaseIds.some(dId => diseaseStates[dId]?.status === Status.INFECTED);
      const hasRecovered = activeDiseaseIds.some(dId => diseaseStates[dId]?.status === Status.RECOVERED);
      
      let overallStatus = Status.SUSCEPTIBLE;
      if (hasInfected) {
        overallStatus = Status.INFECTED;
      } else if (hasRecovered) {
        overallStatus = Status.RECOVERED;
      }

      newBalls.push({
        id: i,
        x,
        y,
        vx: 0,
        vy: 0,
        isMoving: false,
        status: overallStatus,
        opacity: 1.0,
        infectionsCount: 0,
        infectedAt: hasInfected ? 0 : undefined,
        immunityTimeRemaining: 0,
        diseaseStates,
        isVaccinated: hasRecovered
      });
    }

    setBalls(newBalls);
    ballsRef.current = newBalls;
    setObjectCollisions(0);
    setElapsedTime(0);
    elapsedTimeRef.current = 0;
    setHistory([]);
    activeCollisionsRef.current = new Set();
    empiricalStatsRef.current = {
      completedCount: 0,
      totalSecondaryInfections: 0,
      totalDuration: 0,
      diseaseDeaths: 0,
      recoveries: 0
    };
    setEmpiricalStats({
      completedCount: 0,
      totalSecondaryInfections: 0,
      totalDuration: 0,
      diseaseDeaths: 0,
      recoveries: 0
    });
    lastUpdateRef.current = performance.now();
    lastDecisionRef.current = performance.now();
    lastHistoryRef.current = performance.now();
  }, [k, n, vaccinationRate, initialInfectedCount, immunityDuration, activePreset, doorsClosed, activeDiseaseIds, diseaseTabs]);

  useEffect(() => {
    initBalls();
  }, [initBalls]);

  const [selectedDiseaseName, setSelectedDiseaseName] = useState<string | null>("다중 전염병 동시 시뮬레이션");

  const activateTabInSimulation = useCallback((tabId: number) => {
    setEditingTabId(tabId);
    const targetTab = diseaseTabs.find(t => t.id === tabId);
    if (targetTab) {
      setSelectedDiseaseName(targetTab.name);
    }
  }, [diseaseTabs]);

  // Motion Vector changes at short intervals (Random Chaos vs. Intelligent Directional Purpose)
  const makeDecision = useCallback(() => {
    const currentBalls = ballsRef.current;
    // When social distancing is active, reduce speed to 35% of selected speed
    const activeSpeed = socialDistancing ? speed * 0.35 : speed;
    const marginInner = OBJECT_RADIUS + 0.15;

    for (let i = 0; i < currentBalls.length; i++) {
      const ball = currentBalls[i];
      if (ball.status === Status.DEAD) continue;

      if (useIntention) {
        // If the ball is currently waiting/staying, keep it staying
        if (ball.stayTimeRemaining && ball.stayTimeRemaining > 0) {
          ball.vx = 0;
          ball.vy = 0;
          ball.isMoving = false;
          continue;
        }

        let tx = ball.targetX;
        let ty = ball.targetY;
        
        // Determine if target was reached or if none assigned yet
        const reachedTarget = !tx || !ty || Math.hypot(ball.x - tx, ball.y - ty) < 0.45;

        if (reachedTarget) {
          // Reached target! Set a wait stay duration (e.g., 1.5 to 4.5 dynamic seconds)
          // When social distancing is active, increase stay time by 4x
          const baseStay = 1.5 + Math.random() * 3.0;
          const staySecs = socialDistancing ? baseStay * 4.0 : baseStay;
          
          // Pre-assign the *next* target but keep the ball still for now
          const nextTgt = getRandomPresetTarget(activePreset, k);
          ball.isMoving = false;
          ball.vx = 0;
          ball.vy = 0;
          
          // Target Option 1: True destination (shortest-path ideal goal)
          ball.baseTargetX = nextTgt.x;
          ball.baseTargetY = nextTgt.y;

          // Target Option 2 & 3: Two offset/deviated alternatives unique to each individual
          const a1 = Math.random() * Math.PI * 2;
          const d1 = 1.8 + Math.random() * 3.6; // Widened deviation range (1.8 to 5.4) for organic dispersion
          ball.altTarget1X = Math.max(marginInner, Math.min(k - marginInner, nextTgt.x + Math.cos(a1) * d1));
          ball.altTarget1Y = Math.max(marginInner, Math.min(k - marginInner, nextTgt.y + Math.sin(a1) * d1));

          const a2 = Math.random() * Math.PI * 2;
          const d2 = 1.8 + Math.random() * 3.6; // Widened deviation range (1.8 to 5.4)
          ball.altTarget2X = Math.max(marginInner, Math.min(k - marginInner, nextTgt.x + Math.cos(a2) * d2));
          ball.altTarget2Y = Math.max(marginInner, Math.min(k - marginInner, nextTgt.y + Math.sin(a2) * d2));

          // Select initially among three options randomly
          const choices = [
            { x: ball.baseTargetX, y: ball.baseTargetY },
            { x: ball.altTarget1X, y: ball.altTarget1Y },
            { x: ball.altTarget2X, y: ball.altTarget2Y }
          ];
          const selectedIdx = Math.floor(Math.random() * 3);
          ball.selectedTargetIndex = selectedIdx;
          ball.targetX = choices[selectedIdx].x;
          ball.targetY = choices[selectedIdx].y;

          ball.choiceDecisionCounter = 0; // Reset steps counter
          ball.stayTimeRemaining = staySecs;
          continue;
        }

        // Randomly re-select one of the three targets every 5x decision interval steps
        if (ball.choiceDecisionCounter === undefined) {
          ball.choiceDecisionCounter = 0;
        }
        ball.choiceDecisionCounter += 1;

        if (ball.choiceDecisionCounter >= 5) {
          ball.choiceDecisionCounter = 0;

          // Hydrater guard just in case base/alt targets are undefined
          if (ball.baseTargetX === undefined || ball.baseTargetY === undefined) {
            ball.baseTargetX = ball.targetX || ball.x;
            ball.baseTargetY = ball.targetY || ball.y;
            const a1 = Math.random() * Math.PI * 2;
            const d1 = 1.8 + Math.random() * 3.6; // Widened deviation range
            ball.altTarget1X = Math.max(marginInner, Math.min(k - marginInner, ball.baseTargetX + Math.cos(a1) * d1));
            ball.altTarget1Y = Math.max(marginInner, Math.min(k - marginInner, ball.baseTargetY + Math.sin(a1) * d1));
            
            const a2 = Math.random() * Math.PI * 2;
            const d2 = 1.8 + Math.random() * 3.6; // Widened deviation range
            ball.altTarget2X = Math.max(marginInner, Math.min(k - marginInner, ball.baseTargetX + Math.cos(a2) * d2));
            ball.altTarget2Y = Math.max(marginInner, Math.min(k - marginInner, ball.baseTargetY + Math.sin(a2) * d2));
          }

          const choices = [
            { x: ball.baseTargetX, y: ball.baseTargetY },
            { x: ball.altTarget1X, y: ball.altTarget1Y },
            { x: ball.altTarget2X, y: ball.altTarget2Y }
          ];
          const selectedIdx = Math.floor(Math.random() * 3);
          ball.selectedTargetIndex = selectedIdx;
          ball.targetX = choices[selectedIdx].x;
          ball.targetY = choices[selectedIdx].y;
          
          tx = ball.targetX;
          ty = ball.targetY;
        }

        const dx = tx! - ball.x;
        const dy = ty! - ball.y;
        const dist = Math.hypot(dx, dy);

        if (dist > 0.1) {
          ball.isMoving = true;
          ball.vx = (dx / dist) * activeSpeed;
          ball.vy = (dy / dist) * activeSpeed;
        } else {
          ball.isMoving = false;
          ball.vx = 0;
          ball.vy = 0;
        }
      } else {
        // Chaotic Brownian random walks
        const willMove = Math.random() < MOVE_PROBABILITY;
        if (willMove) {
          const angle = Math.random() * Math.PI * 2;
          ball.isMoving = true;
          ball.vx = Math.cos(angle) * activeSpeed;
          ball.vy = Math.sin(angle) * activeSpeed;
          ball.targetX = undefined;
          ball.targetY = undefined;
        } else {
          ball.isMoving = false;
          ball.vx = 0;
          ball.vy = 0;
          ball.targetX = undefined;
          ball.targetY = undefined;
        }
      }
    }
  }, [speed, useIntention, activePreset, k, socialDistancing]);

  // Handle Vital birth, natural deaths, infection periods, and slow decay
  const processLifeCycles = useCallback((dt: number) => {
    let aliveCount = 0;
    const currentBalls = ballsRef.current;
    
    for (let i = 0; i < currentBalls.length; i++) {
      if (currentBalls[i].status !== Status.DEAD) {
        aliveCount++;
      }
    }
    
    // 1. Births (Stochastic Poisson-Arrival emulation based on current population count)
    const birthProbability = (birthRate / 100) * dt * aliveCount;
    if (aliveCount < MAX_POPULATION && Math.random() < birthProbability) {
      const margin = OBJECT_RADIUS + 0.1;
      const x = margin + Math.random() * (k - 2 * margin);
      const y = margin + Math.random() * (k - 2 * margin);
      
      const diseaseStates: { [diseaseId: number]: BallDiseaseState } = {};
      diseaseTabs.forEach(tab => {
        diseaseStates[tab.id] = {
          status: Status.SUSCEPTIBLE,
          immunityTimeRemaining: 0,
          infectedAt: undefined,
          infectionsCount: 0
        };
      });

      const newBall: Ball = {
        id: Date.now() + Math.random(),
        x,
        y,
        vx: 0,
        vy: 0,
        isMoving: false,
        status: Status.SUSCEPTIBLE,
        immunityTimeRemaining: 0,
        opacity: 1.0,
        infectionsCount: 0,
        diseaseStates,
        isVaccinated: false
      };
      currentBalls.push(newBall);
    }

    const recordCompletedInfection = (ball: Ball, dState: BallDiseaseState, diedFromDisease: boolean = false, diedNaturally: boolean = false) => {
      const infectedTime = dState.infectedAt !== undefined ? dState.infectedAt : 0;
      const duration = elapsedTimeRef.current - infectedTime;
      
      empiricalStatsRef.current.completedCount += 1;
      empiricalStatsRef.current.totalSecondaryInfections += (dState.infectionsCount || 0);
      empiricalStatsRef.current.totalDuration += duration;
      if (diedFromDisease) {
        empiricalStatsRef.current.diseaseDeaths += 1;
      } else if (!diedNaturally) {
        empiricalStatsRef.current.recoveries += 1;
      }
    };

    // 2. Iterative states
    const deathProbability = (naturalDeathRate / 100) * dt;

    for (let i = 0; i < currentBalls.length; i++) {
      const b = currentBalls[i];

      // Dead units: Fade out slowly over time
      if (b.status === Status.DEAD) {
        if (b.opacity > 0) {
          b.opacity = b.opacity - dt * 1.2;
          if (b.opacity < 0) b.opacity = 0;
        }
        continue;
      }

      // Natural Death Check
      if (Math.random() < deathProbability) {
        // Record all active infections on the ball before ending them
        activeDiseaseIds.forEach(dId => {
          const dState = b.diseaseStates?.[dId];
          if (dState && dState.status === Status.INFECTED) {
            recordCompletedInfection(b, dState, false, true);
          }
        });

        b.status = Status.DEAD;
        b.vx = 0;
        b.vy = 0;
        continue;
      }

      // Hydrate diseaseStates if undefined
      if (!b.diseaseStates) {
        b.diseaseStates = {};
        diseaseTabs.forEach(tab => {
          b.diseaseStates![tab.id] = {
            status: tab.id === activeSimTabId ? b.status : Status.SUSCEPTIBLE,
            immunityTimeRemaining: tab.id === activeSimTabId ? b.immunityTimeRemaining : 0,
            infectedAt: tab.id === activeSimTabId ? b.infectedAt : undefined,
            infectionsCount: tab.id === activeSimTabId ? (b.infectionsCount || 0) : 0
          };
        });
      }

      // Individual Disease Progression for each active disease
      let hasDiedFromDisease = false;

      for (const dId of activeDiseaseIds) {
        const dState = b.diseaseStates[dId];
        if (!dState) continue;

        const tab = diseaseTabs.find(t => t.id === dId);
        if (!tab) continue;

        const dRecRateDt = (tab.recoveryRate / 100) * dt;
        const dDeathRateDt = (tab.infectionDeathRate / 100) * dt;

        if (dState.status === Status.INFECTED) {
          // Recovery check
          if (Math.random() < dRecRateDt) {
            dState.status = Status.RECOVERED;
            dState.immunityTimeRemaining = tab.immunityDuration;
            recordCompletedInfection(b, dState, false, false);
          }
          // Disease death check
          else if (Math.random() < dDeathRateDt) {
            hasDiedFromDisease = true;
            recordCompletedInfection(b, dState, true, false);

            // Other active infections are ended
            activeDiseaseIds.forEach(otherId => {
              if (otherId !== dId) {
                const otherState = b.diseaseStates?.[otherId];
                if (otherState && otherState.status === Status.INFECTED) {
                  recordCompletedInfection(b, otherState, false, true);
                }
              }
            });
            break;
          }
        } else if (dState.status === Status.RECOVERED) {
          dState.immunityTimeRemaining -= dt;
          if (dState.immunityTimeRemaining <= 0) {
            dState.status = Status.SUSCEPTIBLE;
          }
        }
      }

      if (hasDiedFromDisease) {
        b.status = Status.DEAD;
        b.vx = 0;
        b.vy = 0;
      } else {
        // Sync top-level status to maintain full compatibility across layout, count dashboards, maps, etc.
        syncBallTopLevelState(b, activeDiseaseIds);
      }
    }
  }, [birthRate, naturalDeathRate, infectionDeathRate, recoveryRate, immunityDuration, k, activeDiseaseIds, diseaseTabs, activeSimTabId]);

  // Core Simulation Engine Loop
  useEffect(() => {
    if (!isRunning) return;

    let id: number;

    const loop = (time: number) => {
      const dt = ((time - lastUpdateRef.current) / 1000) * simSpeed;
      lastUpdateRef.current = time;

      // Check Decision state interval scaled by simSpeed
      if (time - lastDecisionRef.current >= decisionIntervalMs / simSpeed) {
        makeDecision();
        lastDecisionRef.current = time;
      }

      // Log statistics history every 1 simulated second
      simAccumulatorRef.current += dt;
      if (simAccumulatorRef.current >= 1.0) {
        const points = Math.floor(simAccumulatorRef.current);
        simAccumulatorRef.current -= points;

        const curStats = {
          time: Math.round(elapsedTimeRef.current + points),
          susceptible: ballsRef.current.filter(b => b.status === Status.SUSCEPTIBLE).length,
          infected: ballsRef.current.filter(b => b.status === Status.INFECTED).length,
          recovered: ballsRef.current.filter(b => b.status === Status.RECOVERED).length,
          dead: ballsRef.current.filter(b => b.status === Status.DEAD && b.opacity > 0).length,
          total: ballsRef.current.filter(b => b.status !== Status.DEAD || b.opacity > 0).length
        };
        setHistory(prev => [...prev.slice(-45), curStats]); // limit history window for plotting efficiency

        // Synchronize React state only once per simulated second to completely avoid 60 FPS useless re-renders
        setElapsedTime(elapsedTimeRef.current);
        setBalls([...ballsRef.current]);
        setEmpiricalStats({ ...empiricalStatsRef.current });
      }

      elapsedTimeRef.current += dt;
      processLifeCycles(dt);

      const currentBalls = [...ballsRef.current];
      let newObjectCollisions = 0;

      // Update location positions
      for (const b of currentBalls) {
        if (b.status === Status.DEAD) continue;

        // Count down stay times in place
        if (b.stayTimeRemaining && b.stayTimeRemaining > 0) {
          b.stayTimeRemaining = Math.max(0, b.stayTimeRemaining - dt);
          b.vx = 0;
          b.vy = 0;
          b.isMoving = false;
        } else {
          const activeSpeed = socialDistancing ? speed * 0.35 : speed;

          if (useIntention && b.targetX !== undefined && b.targetY !== undefined) {
            const tx = b.targetX;
            const ty = b.targetY;
            const dx = tx - b.x;
            const dy = ty - b.y;
            const dist = Math.hypot(dx, dy);

            if (dist > 0.25) {
              const desiredVx = (dx / dist) * activeSpeed;
              const desiredVy = (dy / dist) * activeSpeed;

              // Smooth steering transition (inertia & momentum)
              const steerFactor = Math.min(1.0, (steeringSpeed / 100) * (dt * 30));
              b.vx += (desiredVx - b.vx) * steerFactor;
              b.vy += (desiredVy - b.vy) * steerFactor;
              b.isMoving = true;
            } else {
              // Soft deceleration near target
              b.vx *= 0.65;
              b.vy *= 0.65;
              if (Math.hypot(b.vx, b.vy) < 0.05) {
                b.vx = 0;
                b.vy = 0;
                b.isMoving = false;
              }
            }
          }

          // Add passive Brownian micro-wiggle (adds lifelike, organic, human-like sway)
          if (enableWiggle) {
            const wiggleAmt = 0.16 * activeSpeed * (dt * 15);
            b.vx += (Math.random() - 0.5) * wiggleAmt;
            b.vy += (Math.random() - 0.5) * wiggleAmt;

            // Constrain velocity magnitude relative to speed baselines
            const currentSpeed = Math.hypot(b.vx, b.vy);
            const maxAllowed = activeSpeed * 1.35;
            if (currentSpeed > maxAllowed) {
              b.vx = (b.vx / currentSpeed) * maxAllowed;
              b.vy = (b.vy / currentSpeed) * maxAllowed;
            }
          }

          b.x += b.vx * dt;
          b.y += b.vy * dt;
        }

        // Record coordinates for Infected Trails tracking
        if (!b.trail) b.trail = [];
        if (b.status === Status.INFECTED) {
          b.trail.push({ x: b.x, y: b.y });
          if (b.trail.length > 25) {
            b.trail.shift();
          }
        } else {
          // Gradual fading when recovered/susceptible
          if (b.trail.length > 0) {
            b.trail.shift();
          }
        }

        // Bounce from confining borders gracefully
        if (b.x - OBJECT_RADIUS < 0) { b.x = OBJECT_RADIUS; b.vx *= -1; b.targetX = undefined; b.targetY = undefined; }
        else if (b.x + OBJECT_RADIUS > k) { b.x = k - OBJECT_RADIUS; b.vx *= -1; b.targetX = undefined; b.targetY = undefined; }
        if (b.y - OBJECT_RADIUS < 0) { b.y = OBJECT_RADIUS; b.vy *= -1; b.targetX = undefined; b.targetY = undefined; }
        else if (b.y + OBJECT_RADIUS > k) { b.y = k - OBJECT_RADIUS; b.vy *= -1; b.targetX = undefined; b.targetY = undefined; }

        // Physics resolve against active preset walls with togglable smooth sliding behavior
        resolveWallCollisions(b, activeWalls, slideAlongWalls);
      }

      // 1.5 Handle inter-agent elastic collisions if enabled to avoid unrealistic crowd bundling
      if (enableBallCollision) {
        resolveBallCollisions(currentBalls, k, activePreset);
      }

      // Handle continuous close contact & epidemic transmission matrix (Pass-through)
      const currentFrameCollisions = new Set<string>();
      for (let i = 0; i < currentBalls.length; i++) {
        for (let j = i + 1; j < currentBalls.length; j++) {
          const b1 = currentBalls[i];
          const b2 = currentBalls[j];
          if (b1.status === Status.DEAD || b2.status === Status.DEAD) continue;

          const dx = b2.x - b1.x;
          const dy = b2.y - b1.y;
          if (dx * dx + dy * dy < OBJECT_DIAMETER * OBJECT_DIAMETER) {
            // Check if there is an active wall blocking the direct path between the two balls
            let blockedByWall = false;
            for (let w = 0; w < activeWalls.length; w++) {
              const wall = activeWalls[w];
              if (segmentsIntersect(b1.x, b1.y, b2.x, b2.y, wall.x1, wall.y1, wall.x2, wall.y2)) {
                blockedByWall = true;
                break;
              }
            }
            if (blockedByWall) continue;

            const id1 = b1.id;
            const id2 = b2.id;
            const pairId = id1 < id2 ? id1 + "_" + id2 : id2 + "_" + id1;
            currentFrameCollisions.add(pairId);

            // Record as a unique collision instance on entry
            if (!activeCollisionsRef.current.has(pairId)) {
              newObjectCollisions++;

              // Contact transmitted vectors for each active disease
              activeDiseaseIds.forEach(dId => {
                if (!b1.diseaseStates) {
                  b1.diseaseStates = {};
                  diseaseTabs.forEach(tab => {
                    b1.diseaseStates![tab.id] = {
                      status: tab.id === activeSimTabId ? b1.status : Status.SUSCEPTIBLE,
                      opacity: b1.opacity,
                      immunityTimeRemaining: tab.id === activeSimTabId ? b1.immunityTimeRemaining : 0,
                      infectedAt: tab.id === activeSimTabId ? b1.infectedAt : undefined,
                      infectionsCount: tab.id === activeSimTabId ? (b1.infectionsCount || 0) : 0
                    } as any;
                  });
                }
                if (!b2.diseaseStates) {
                  b2.diseaseStates = {};
                  diseaseTabs.forEach(tab => {
                    b2.diseaseStates![tab.id] = {
                      status: tab.id === activeSimTabId ? b2.status : Status.SUSCEPTIBLE,
                      opacity: b2.opacity,
                      immunityTimeRemaining: tab.id === activeSimTabId ? b2.immunityTimeRemaining : 0,
                      infectedAt: tab.id === activeSimTabId ? b2.infectedAt : undefined,
                      infectionsCount: tab.id === activeSimTabId ? (b2.infectionsCount || 0) : 0
                    } as any;
                  });
                }

                const dState1 = b1.diseaseStates[dId];
                const dState2 = b2.diseaseStates[dId];
                if (!dState1 || !dState2) return;

                const tab = diseaseTabs.find(t => t.id === dId);
                const prob = tab ? tab.transmissionProb : transmissionProb;

                if (dState1.status === Status.INFECTED && dState2.status === Status.SUSCEPTIBLE) {
                  if (Math.random() * 100 < prob) {
                    dState2.status = Status.INFECTED;
                    dState2.infectedAt = elapsedTimeRef.current;
                    dState2.infectionsCount = 0;
                    dState1.infectionsCount = (dState1.infectionsCount || 0) + 1;
                  }
                } else if (dState2.status === Status.INFECTED && dState1.status === Status.SUSCEPTIBLE) {
                  if (Math.random() * 100 < prob) {
                    dState1.status = Status.INFECTED;
                    dState1.infectedAt = elapsedTimeRef.current;
                    dState1.infectionsCount = 0;
                    dState2.infectionsCount = (dState2.infectionsCount || 0) + 1;
                  }
                }
              });

              // Sync overall status for both balls after transmission tests
              syncBallTopLevelState(b1, activeDiseaseIds);
              syncBallTopLevelState(b2, activeDiseaseIds);
            }
          }
        }
      }

      activeCollisionsRef.current = currentFrameCollisions;
      if (newObjectCollisions > 0) setObjectCollisions(prev => prev + newObjectCollisions);
      
      ballsRef.current = currentBalls;
      render();
      id = requestAnimationFrame(loop);
    };

    const render = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      const scale = canvas.width / k;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // 1. Draw Architectural Building Blueprint Plan behind grid lines
      drawBuildingBlueprint(ctx, k, scale, activePreset, doorsClosed);

      // 2. Grid System rendering with soft aesthetic lines
      ctx.strokeStyle = 'rgba(229, 231, 235, 0.15)';
      ctx.lineWidth = 0.5;
      for (let i = 0; i <= k; i++) {
        ctx.beginPath(); ctx.moveTo(i * scale, 0); ctx.lineTo(i * scale, canvas.height); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, i * scale); ctx.lineTo(canvas.width, i * scale); ctx.stroke();
      }

      // 2.2 Draw Vaccination Coverage Density Heatmap Overlay
      drawVaccineHeatmap(ctx, ballsRef.current, k, canvas.width, canvas.height, heatmapMode);

      // 2.5 Draw Infected Exposure Trails with beautiful double-glowing overlay (궤적)
      ctx.save();
      ballsRef.current.forEach(ball => {
        if (ball.trail && ball.trail.length > 1) {
          ctx.beginPath();
          ctx.moveTo(ball.trail[0].x * scale, ball.trail[0].y * scale);
          for (let i = 1; i < ball.trail.length; i++) {
            ctx.lineTo(ball.trail[i].x * scale, ball.trail[i].y * scale);
          }

          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';

          // Outer glowing crimson aura path
          ctx.lineWidth = OBJECT_RADIUS * scale * 1.15;
          ctx.strokeStyle = `rgba(239, 68, 68, ${0.14 * ball.opacity})`;
          ctx.stroke();

          // Inner intense pinkish-red heat core trace
          ctx.lineWidth = OBJECT_RADIUS * scale * 0.45;
          ctx.strokeStyle = `rgba(248, 113, 113, ${0.36 * ball.opacity})`;
          ctx.stroke();
        }
      });
      ctx.restore();

      // 3. Draw all individual ball states...
      ballsRef.current.forEach(ball => {
        drawSingleBall(ctx, ball, scale, activeDiseaseIds, diseaseTabs, transmissionProb);
      });
    };

    id = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(id);
  }, [isRunning, k, makeDecision, processLifeCycles, transmissionProb, decisionIntervalMs, simSpeed, activePreset, doorsClosed, activeWalls, heatmapMode, steeringSpeed, enableBallCollision, enableWiggle, slideAlongWalls, activeDiseaseIds, diseaseTabs]);

  // Secondary backup renderer when configuration stats are refreshed or paused
  useEffect(() => {
    if (isRunning) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const scale = canvas.width / k;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // 1. Draw Architectural Building Blueprint Plan behind grid lines
    drawBuildingBlueprint(ctx, k, scale, activePreset, doorsClosed);

    // 2. Grid System rendering with soft aesthetic lines
    ctx.strokeStyle = 'rgba(229, 231, 235, 0.15)';
    ctx.lineWidth = 0.5;
    for (let i = 0; i <= k; i++) {
      ctx.beginPath(); ctx.moveTo(i * scale, 0); ctx.lineTo(i * scale, canvas.height); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, i * scale); ctx.lineTo(canvas.width, i * scale); ctx.stroke();
    }

    // 2.2 Draw Vaccination Coverage Density Heatmap Overlay
    drawVaccineHeatmap(ctx, ballsRef.current, k, canvas.width, canvas.height, heatmapMode);

    // 2.5 Draw Infected Exposure Trails with beautiful double-glowing overlay (궤적)
    ctx.save();
    ballsRef.current.forEach(ball => {
      if (ball.trail && ball.trail.length > 1) {
        ctx.beginPath();
        ctx.moveTo(ball.trail[0].x * scale, ball.trail[0].y * scale);
        for (let i = 1; i < ball.trail.length; i++) {
          ctx.lineTo(ball.trail[i].x * scale, ball.trail[i].y * scale);
        }

        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';

        // Outer glowing crimson aura path
        ctx.lineWidth = OBJECT_RADIUS * scale * 1.15;
        ctx.strokeStyle = `rgba(239, 68, 68, ${0.14 * ball.opacity})`;
        ctx.stroke();

        // Inner intense pinkish-red heat core trace
        ctx.lineWidth = OBJECT_RADIUS * scale * 0.45;
        ctx.strokeStyle = `rgba(248, 113, 113, ${0.36 * ball.opacity})`;
        ctx.stroke();
      }
    });
    ctx.restore();

    ballsRef.current.forEach(ball => {
      drawSingleBall(ctx, ball, scale, activeDiseaseIds, diseaseTabs, transmissionProb);
    });
  }, [balls, k, isRunning, activePreset, doorsClosed, heatmapMode, steeringSpeed, enableBallCollision, enableWiggle, slideAlongWalls, activeDiseaseIds, diseaseTabs, transmissionProb]);

  // Aggregate values
  const stats = useMemo(() => {
    const infected = balls.filter(b => b.status === Status.INFECTED).length;
    const recovered = balls.filter(b => b.status === Status.RECOVERED).length;
    const susceptible = balls.filter(b => b.status === Status.SUSCEPTIBLE).length;
    const dead = balls.filter(b => b.status === Status.DEAD && b.opacity > 0).length;
    const totalDeadCount = balls.filter(b => b.status === Status.DEAD).length;
    const alive = infected + recovered + susceptible;
    const immunityRate = alive > 0 ? (recovered / alive) * 100 : 0;
    return { infected, recovered, susceptible, dead, totalDeadCount, alive, immunityRate };
  }, [balls]);

  // Standard frequency contacts calculation
  const contactRatePer60s = elapsedTime > 0
    ? ((objectCollisions * 2) / (n * elapsedTime)) * 60
    : 0;

  // Theoretical calculations (Dependent on contactRatePer60s)
  const theoreticalR0Val = useMemo(() => {
    const c_sec = contactRatePer60s / 60;
    const p = transmissionProb / 100;
    const r = recoveryRate / 100;
    const d = infectionDeathRate / 100;
    if (r + d === 0) return 0;
    return (c_sec * p) / (r + d);
  }, [contactRatePer60s, transmissionProb, recoveryRate, infectionDeathRate]);

  const theoreticalIFRVal = useMemo(() => {
    const r = recoveryRate;
    const d = infectionDeathRate;
    if (r + d === 0) return 0;
    return (d / (r + d)) * 100;
  }, [recoveryRate, infectionDeathRate]);

  const theoreticalDurationVal = useMemo(() => {
    const r_sec = recoveryRate / 100;
    const d_sec = infectionDeathRate / 100;
    if (r_sec + d_sec === 0) return 0;
    return 1 / (r_sec + d_sec);
  }, [recoveryRate, infectionDeathRate]);

  // Python Code Generation with customizable parameters matching the Stochastic SEIR algorithm
  const pythonScriptText = useMemo(() => {
    return `import numpy as np
import matplotlib.pyplot as plt

# Stochastic SEIR epidemic simulation code with birth-death demographics
# Auto-generated based on current dashboard parameters

# --- PARAMETERS ---
N = 10000              # Total static population
INITIAL_EXPOSED = 15   # Initial exposed patients counts (E)
INITIAL_INFECTED = ${initialInfectedCount}   # Initial infections (I)
INITIAL_RECOVERED = int(N * ${vaccinationRate} / 100) # Initial Vaccinated (R)

# Transition Rates
INCU_PERIOD = 5.0      # Incubation period (1/sigma)
INF_PERIOD = ${immunityDuration ? (immunityDuration / 2).toFixed(1) : '7.0'}       # Infectious period (1/gamma)
BIRTH_DEATH_RATE = ${(naturalDeathRate / 100).toFixed(6)} # Daily Demographics rate (mu = nu)

sigma = 1.0 / INCU_PERIOD
gamma = 1.0 / INF_PERIOD
beta_transmission = ${transmissionProb / 100} # Transmission weight (probability)
contact_rate = ${speed ? (speed / 1.5).toFixed(2) : '4.0'}        # Average daily contact frequency (c)
beta = contact_rate * beta_transmission # Combined rate (beta = c * beta_trans)

DAYS = 90
dt = 1.0 # 1-day step increments

def run_single_simulation():
    # State series initialized
    S = [N - INITIAL_EXPOSED - INITIAL_INFECTED - INITIAL_RECOVERED]
    E = [INITIAL_EXPOSED]
    I = [INITIAL_INFECTED]
    R = [INITIAL_RECOVERED]
    D = [0] # Dead accumulation
    
    for t in range(DAYS):
        S_t, E_t, I_t, R_t, D_t = S[-1], E[-1], I[-1], R[-1], D[-1]
        current_N = S_t + E_t + I_t + R_t
        if current_N <= 0:
            break
            
        # Stochastic Transition Binomial Probabilities
        p_exposure = 1.0 - np.exp(-beta * (I_t / current_N) * dt)
        p_infection = 1.0 - np.exp(-sigma * dt)
        p_recovery = 1.0 - np.exp(-gamma * dt)
        p_demise = 1.0 - np.exp(-BIRTH_DEATH_RATE * dt)
        
        # Draw arrivals under binomial limits
        new_exposed = np.random.binomial(int(S_t), p_exposure) if S_t > 0 else 0
        new_infected = np.random.binomial(int(E_t), p_infection) if E_t > 0 else 0
        new_recovered = np.random.binomial(int(I_t), p_recovery) if I_t > 0 else 0
        
        # Demographics transitions (Vital Dynamics)
        births = np.random.poisson(BIRTH_DEATH_RATE * current_N)
        deaths_S = np.random.binomial(int(S_t), p_demise) if S_t > 0 else 0
        deaths_E = np.random.binomial(int(E_t), p_demise) if E_t > 0 else 0
        deaths_I = np.random.binomial(int(I_t), p_demise) if I_t > 0 else 0
        deaths_R = np.random.binomial(int(R_t), p_demise) if R_t > 0 else 0
        
        # Update Equations
        S_next = max(0, S_t - new_exposed + births - deaths_S)
        E_next = max(0, E_t + new_exposed - new_infected - deaths_E)
        I_next = max(0, I_t + new_infected - new_recovered - deaths_I)
        R_next = max(0, R_t + new_recovered - deaths_R)
        D_next = D_t + deaths_S + deaths_E + deaths_I + deaths_R
        
        S.append(S_next)
        E.append(E_next)
        I.append(I_next)
        R.append(R_next)
        D.append(D_next)
        
    return np.array(S), np.array(E), np.array(I), np.array(R), np.array(D)

# Run Monte Carlo Ensemble
simulations_count = 10
results_I = []
results_R = []

for _ in range(simulations_count):
    _, _, I_series, R_series, _ = run_single_simulation()
    results_I.append(I_series)
    results_R.append(R_series)

# Plotting the outputs
plt.figure(figsize=(10, 6))
time_axis = np.arange(DAYS + 1)

# Plot individual simulations to show stochastic variance
for index in range(simulations_count):
    plt.plot(time_axis, results_I[index], color='red', alpha=0.25)
    plt.plot(time_axis, results_R[index], color='green', alpha=0.15)

# Summarize mean trajectories
mean_I = np.mean(results_I, axis=0)
mean_R = np.mean(results_R, axis=0)

plt.plot(time_axis, mean_I, color='red', label='Infected (Mean Trajectory)', linewidth=2)
plt.plot(time_axis, mean_R, color='green', label='Immune Recovered (Mean)', linewidth=2)

plt.title('Stochastic SEIR Epidemic Curve with Demographics', fontsize=12, fontweight='bold')
plt.xlabel('Time (Days)', fontsize=10)
plt.ylabel('People Count', fontsize=10)
plt.grid(True, linestyle='--', opacity=0.5)
plt.legend(frameon=True, facecolor='white', shadow=True)
plt.tight_layout()
plt.show()
`;
  }, [vaccinationRate, initialInfectedCount, immunityDuration, naturalDeathRate, transmissionProb, speed]);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(pythonScriptText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadPythonScript = () => {
    const blob = new Blob([pythonScriptText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'stochastic_seir_simulation.py';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-neutral-900 p-4 md:p-8 font-sans text-neutral-100 selection:bg-rose-500 selection:text-white">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Top Header Row with quick controls */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-neutral-800/60 p-6 rounded-3xl border border-neutral-700/50 backdrop-blur-md">
          <header className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-rose-500/10 text-rose-400 text-xs font-black tracking-widest uppercase flex items-center gap-1">
                <Sparkles size={10} /> Active Stochastic Engine
              </span>
            </div>
            <h1 className="text-3xl font-extrabold tracking-tight text-white flex items-center gap-2">
              Epidemic <span className="bg-gradient-to-r from-rose-400 to-amber-400 bg-clip-text text-transparent">Spatiotemporal Dynamics</span>
            </h1>
            <p className="text-neutral-400 text-xs font-medium">
              출산, 사망, 유입, 전파 위험지속의 물리 환경을 제어하고, 감염병 예측 수치와 기초 감염 재생산 지표를 비교합니다.
            </p>
          </header>
          
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setIsPythonModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold bg-neutral-700 hover:bg-neutral-600 text-neutral-100 text-xs shadow-md border border-neutral-600/40 transition-all cursor-pointer"
            >
              <Terminal size={14} />
              Python Stochastic SEIR 소스코드 얻기
            </button>
            
            {/* Simulation Speed Control Unit */}
            <div className="flex items-center gap-1 bg-neutral-850 p-1 rounded-xl border border-neutral-700/60 shadow-inner">
              <span className="text-[10px] uppercase font-black text-neutral-400 px-2 tracking-wider">배속</span>
              {[0.5, 1.0, 2.0, 4.0].map((rate) => {
                const active = simSpeed === rate;
                return (
                  <button
                    key={rate}
                    onClick={() => setSimSpeed(rate)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-mono font-black transition-all cursor-pointer ${
                      active 
                        ? 'bg-rose-600 text-white shadow-sm' 
                        : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
                    }`}
                  >
                    {rate}x
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => {
                if (isRunning) {
                  setElapsedTime(elapsedTimeRef.current);
                  setBalls([...ballsRef.current]);
                }
                lastUpdateRef.current = performance.now();
                lastDecisionRef.current = performance.now();
                lastHistoryRef.current = performance.now();
                setIsRunning(!isRunning);
              }}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs shadow-md transition-all cursor-pointer ${
                isRunning 
                  ? "bg-neutral-100 text-neutral-900" 
                  : "bg-rose-600 text-white hover:bg-rose-500 shadow-rose-900/30 font-black"
              }`}
            >
              {isRunning ? <Pause size={14} fill="currentColor" /> : <Play size={14} fill="currentColor" />}
              {isRunning ? "시뮬레이션 일시 정지" : "시뮬레이션 가동"}
            </button>

            <button
              onClick={() => { setIsRunning(false); initBalls(); }}
              className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl font-bold bg-neutral-800 text-neutral-300 hover:bg-neutral-700 text-xs border border-neutral-700/60 transition-all cursor-pointer"
            >
              <RotateCcw size={14} />
              초기화
            </button>

            {/* Social Distancing Toggle Button */}
            <button
              id="social-distancing-toggle"
              onClick={() => setSocialDistancing(!socialDistancing)}
              className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-black text-xs border transition-all cursor-pointer ${
                socialDistancing 
                  ? "bg-blue-600 border-blue-500 text-white shadow-md shadow-blue-500/20" 
                  : "bg-neutral-800 border-neutral-700/60 text-neutral-400 hover:bg-neutral-700 hover:text-neutral-200"
              }`}
            >
              <Shield size={14} className={socialDistancing ? "animate-pulse text-blue-100" : ""} />
              사회적 거리두기 {socialDistancing ? "활성화됨" : "비활성"}
            </button>

            {/* Heatmap Overlay Toggle Segment */}
            <div className="flex items-center bg-neutral-800 border border-neutral-700/60 rounded-xl p-1 gap-1 shadow-md">
              <span className="text-[9px] font-black text-neutral-450 uppercase px-2 py-1 flex items-center gap-1 leading-none">
                <Sparkles size={11} className="text-amber-500" />
                접종 밀도 히트맵
              </span>
              <button
                type="button"
                onClick={() => setHeatmapMode('off')}
                className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                  heatmapMode === 'off'
                    ? "bg-neutral-750 text-white font-black border border-neutral-700/50"
                    : "text-neutral-500 hover:text-neutral-300"
                }`}
              >
                끄기
              </button>
              <button
                type="button"
                onClick={() => setHeatmapMode('smooth')}
                className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                  heatmapMode === 'smooth'
                    ? "bg-emerald-600/90 text-white font-black shadow-sm"
                    : "text-neutral-400 hover:text-neutral-200"
                }`}
              >
                부드럽게
              </button>
              <button
                type="button"
                onClick={() => setHeatmapMode('grid')}
                className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                  heatmapMode === 'grid'
                    ? "bg-cyan-600/95 text-white font-black shadow-sm"
                    : "text-neutral-400 hover:text-neutral-200"
                }`}
              >
                격자분석
              </button>
            </div>
          </div>
        </div>

        {/* Situation / Environment Presets Filters */}
        <div className="space-y-2">
          <label className="text-[10px] font-black uppercase text-neutral-400 tracking-wider flex items-center gap-1 px-1">
            <Clock size={12} className="text-rose-400" /> 시나리오 환경 설정 필터 (학교, 사무실, 대중교통 등 공간 밀집 디테일 변환)
          </label>
          <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
            {Object.entries(PRESETS).map(([key, value]) => {
              const works = activePreset === key;
              return (
                <button
                  key={key}
                  onClick={() => applyPreset(key)}
                  className={`relative p-3 rounded-2xl text-left border transition-all cursor-pointer group flex flex-col justify-between h-24 ${
                    works 
                      ? "bg-neutral-800 border-rose-500 shadow-lg shadow-rose-950/20" 
                      : "bg-neutral-800/40 border-neutral-800 hover:bg-neutral-800 hover:border-neutral-700"
                  }`}
                >
                  <div className="flex justify-between items-start w-full">
                    <span className="text-xl">{value.icon}</span>
                    {works && <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />}
                  </div>
                  <div>
                    <h4 className="text-[11px] font-black text-white truncate leading-tight">{value.name}</h4>
                    <p className="text-[9px] text-neutral-400 font-medium truncate mt-0.5">{value.description}</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Dashboard Panels */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Controls - Left */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-neutral-800/60 p-6 rounded-3xl border border-neutral-700/40 space-y-6 backdrop-blur-md">
              <div className="flex items-center gap-2 text-xs font-bold text-neutral-200">
                <Settings2 size={16} className="text-rose-400" />
                <span>시동 매개변수 (전체 수치 입력 및 조정)</span>
              </div>

              <div className="space-y-4">
                
                {/* Physical Controls */}
                <div className="space-y-3 p-3 bg-neutral-900/60 rounded-2xl border border-neutral-800/50">
                  <p className="text-[9px] font-black uppercase text-amber-500 tracking-wide pb-1 border-b border-neutral-800">공간 기하학 및 개체 밀도</p>
                  
                  <div className="grid grid-cols-3 gap-2">
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-neutral-450 uppercase tracking-tight block truncate">공간 크기 (k)</label>
                      <input 
                        type="number" 
                        min="5" 
                        max="80" 
                        value={k} 
                        onChange={e => { setK(Math.min(80, Math.max(5, Number(e.target.value)))); setIsRunning(false); }} 
                        className="w-full px-2 py-1.5 bg-neutral-800 border border-neutral-700 hover:border-neutral-600 focus:border-rose-500 focus:outline-none rounded-xl text-xs font-mono font-bold text-white transition-all text-center" 
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-neutral-450 uppercase tracking-tight block truncate">총 밀밀집 (n)</label>
                      <input 
                        type="number" 
                        min="1" 
                        max="180" 
                        value={n} 
                        onChange={e => { 
                          const newN = Math.min(180, Math.max(1, Number(e.target.value)));
                          setN(newN); 
                          if (initialInfectedCount > newN) {
                            setInitialInfectedCount(newN);
                          }
                          setIsRunning(false); 
                        }} 
                        className="w-full px-2 py-1.5 bg-neutral-800 border border-neutral-700 hover:border-neutral-600 focus:border-rose-500 focus:outline-none rounded-xl text-xs font-mono font-bold text-white transition-all text-center" 
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-rose-450 uppercase tracking-tight block truncate">초기 감염 (I₀)</label>
                      <input 
                        type="number" 
                        min="1" 
                        max={Math.min(100, n)} 
                        value={initialInfectedCount} 
                        onChange={e => { 
                          const val = Math.min(n, Math.max(1, Number(e.target.value)));
                          setInitialInfectedCount(val); 
                          setIsRunning(false); 
                        }} 
                        className="w-full px-2 py-1.5 bg-neutral-800 border border-neutral-700 hover:border-neutral-600 focus:border-rose-500 focus:outline-none rounded-xl text-xs font-mono font-bold text-rose-400 transition-all text-center" 
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-neutral-400 uppercase">평균 속도 ({speed})</label>
                      <input 
                        type="range" 
                        min="0" 
                        max="15" 
                        step="0.5" 
                        value={speed} 
                        onChange={e => setSpeed(Number(e.target.value))} 
                        className="w-full h-1 bg-neutral-700 rounded-lg appearance-none cursor-pointer accent-rose-500" 
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-neutral-400 uppercase">판단 간격 ({decisionIntervalMs}ms)</label>
                      <input 
                        type="range" 
                        min="50" 
                        max="800" 
                        step="50" 
                        value={decisionIntervalMs} 
                        onChange={e => setDecisionIntervalMs(Number(e.target.value))} 
                        className="w-full h-1 bg-neutral-700 rounded-lg appearance-none cursor-pointer accent-rose-500" 
                      />
                    </div>
                  </div>
                </div>

                {/* Biological Parameters with Multiple Chrome-like tabs */}
                <div className="space-y-4 p-4 bg-neutral-900/60 rounded-3xl border border-neutral-800/50">
                  <div className="flex flex-col gap-1 pb-1 border-b border-neutral-800">
                    <p className="text-[10px] font-black uppercase text-rose-500 tracking-wide flex items-center gap-1">
                      <Sparkles size={11} className="text-rose-400 animate-pulse" />
                      🔍 실시간 다중 전염병 탐구 및 설계 (새 탭 개설)
                    </p>
                    <p className="text-[8px] text-neutral-400 leading-normal">
                      크롬 탭처럼 <strong className="text-rose-400">새 탭(+)</strong>을 열어 복수의 전염병을 동시 가동하고 실시간 계수를 제어하세요.
                    </p>
                  </div>

                  {/* Chrome-like Tab Bar */}
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1.5 pt-1 scrollbar-none">
                    {diseaseTabs.map((tab) => {
                      const isEditing = editingTabId === tab.id;
                      const tabColor = getDiseaseColor(tab.id, diseaseTabs);
                      return (
                        <div
                          key={tab.id}
                          onClick={() => setEditingTabId(tab.id)}
                          className={`group relative flex items-center gap-2 px-3.5 py-1.5 rounded-xl transition-all cursor-pointer select-none border text-[10px] whitespace-nowrap ${
                            isEditing
                              ? "bg-neutral-850 border-neutral-750 text-white font-black shadow-md shadow-neutral-950/40"
                              : "bg-transparent border-transparent text-neutral-500 hover:text-neutral-300 hover:bg-neutral-850/20"
                          }`}
                        >
                          <span
                            className="w-2 h-2 rounded-full flex-shrink-0"
                            style={{ backgroundColor: tabColor }}
                          />
                          <span className="max-w-[70px] truncate">{tab.name}</span>
                          {diseaseTabs.length > 1 && (
                            <button
                              type="button"
                              onClick={(e) => removeTab(tab.id, e)}
                              className="w-3 h-3 rounded-full flex items-center justify-center text-neutral-500 hover:text-rose-400 hover:bg-rose-950/60 text-[9px] leading-none transition-colors"
                              title="삭제"
                            >
                              ×
                            </button>
                          )}
                        </div>
                      );
                    })}

                    <button
                      type="button"
                      onClick={addNewTab}
                      className="flex items-center justify-center w-6 h-6 rounded-lg bg-neutral-800 hover:bg-rose-950/40 border border-neutral-700/60 hover:border-rose-500/35 text-neutral-400 hover:text-rose-400 transition-all cursor-pointer"
                      title="새 전염병 연구 탭 추가"
                    >
                      <Plus size={12} className="stroke-[3]" />
                    </button>
                  </div>

                  {/* Selected Tab Layout with Preset Options */}
                  {(() => {
                    const editingTab = diseaseTabs.find(t => t.id === editingTabId) || diseaseTabs[0];
                    return (
                      <div className="space-y-3.5 pt-1">
                        {/* Title and Template Input Rows */}
                        <div className="space-y-2.5 bg-neutral-950/20 p-2.5 rounded-2xl border border-neutral-850">
                          {/* 1. Name Input */}
                          <div className="space-y-1">
                            <span className="text-[8px] font-black uppercase text-neutral-450 block">연구명 변경</span>
                            <input
                              type="text"
                              value={editingTab.name}
                              onChange={(e) => updateEditingTabName(e.target.value)}
                              className="w-full text-[10px] font-black text-neutral-200 bg-neutral-950/50 px-2.5 py-1.5 rounded-xl border border-neutral-805 focus:border-rose-500/50 focus:ring-1 focus:ring-rose-500/30 overflow-ellipsis outline-none"
                              placeholder="예: 코로나 변이 델타"
                            />
                          </div>

                          {/* 2. Disease Base Template Selectors */}
                          <div className="space-y-1">
                            <span className="text-[8px] font-black uppercase text-neutral-450 block">전염병 유형 선택</span>
                            <div className="grid grid-cols-3 gap-1">
                              {DISEASE_PRESETS.map((preset) => {
                                const isPresetSelected = editingTab.presetKey === preset.key;
                                return (
                                  <button
                                    key={preset.key}
                                    type="button"
                                    onClick={() => applyPresetToEditingTab(preset.key)}
                                    className={`py-1 px-1.5 rounded-lg text-[9px] font-bold text-center transition-all cursor-pointer truncate ${
                                      isPresetSelected
                                        ? "bg-rose-950/40 border border-rose-500/50 text-rose-300"
                                        : "bg-neutral-900/40 border border-neutral-850 text-neutral-400 hover:text-neutral-300 hover:bg-neutral-850/40"
                                    }`}
                                  >
                                    {preset.name.split(" ")[0]}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        </div>

                        {/* Disease Clinical Info */}
                        <div className="p-2.5 bg-neutral-950/30 rounded-2xl border border-neutral-850 text-[10px] space-y-2">
                          <p className="text-[9px] text-neutral-400 leading-relaxed italic border-l-2 border-rose-500/20 pl-2">
                            "{editingTab.desc}"
                          </p>
                          <div className="grid grid-cols-3 gap-1.5 text-center font-mono text-[9px] border-t border-neutral-800/50 pt-2">
                            <div className="bg-neutral-950/40 p-1 rounded-lg border border-neutral-800/40">
                              <div className="text-[7px] text-neutral-500 uppercase">전염성 (R₀)</div>
                              <div className="text-[10px] text-rose-400 font-extrabold mt-0.5">
                                {editingTab.presetKey === "custom" ? (editingTab.transmissionProb / 10).toFixed(1) + " ~ " + (editingTab.transmissionProb / 5).toFixed(1) : editingTab.r0}
                              </div>
                            </div>
                            <div className="bg-neutral-950/40 p-1 rounded-lg border border-neutral-800/40">
                              <div className="text-[7px] text-neutral-500 uppercase">치명률 (IFR)</div>
                              <div className="text-[10px] text-rose-300 font-semibold mt-0.5">
                                {editingTab.presetKey === "custom" ? (editingTab.infectionDeathRate * 3).toFixed(1) + "%" : editingTab.ifr}
                              </div>
                            </div>
                            <div className="bg-neutral-950/40 p-1 rounded-lg border border-neutral-800/40">
                              <div className="text-[7px] text-neutral-500 uppercase">평균 수명</div>
                              <div className="text-[10px] text-indigo-400 font-bold mt-0.5">
                                {editingTab.presetKey === "custom" ? `${editingTab.immunityDuration}초` : editingTab.duration}
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Reset & Run Outbreak button */}
                        <button
                          onClick={() => {
                            setIsRunning(false);
                            setTimeout(() => {
                              initBalls();
                              setIsRunning(true);
                            }, 50);
                          }}
                          className="w-full py-2 bg-rose-600 hover:bg-rose-500 text-white font-extrabold text-[10px] rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-md shadow-rose-950/40 border border-rose-500/25"
                        >
                          <RotateCcw size={10} />
                          다중 전염 시뮬레이션 폭발 초기화 (Reset outbreak)
                        </button>
                      </div>
                    );
                  })()}

                {/* Biological parameters sliders linked to the chosen edit workspace */}
                {(() => {
                  const editingTab = diseaseTabs.find(t => t.id === editingTabId) || diseaseTabs[0];
                    return (
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-[9px] font-bold text-neutral-400 uppercase flex justify-between">
                              <span>전파 확률</span>
                              <span className="font-mono text-rose-400 font-extrabold">{editingTab.transmissionProb}%</span>
                            </label>
                            <input 
                              type="range" 
                              min="0" 
                              max="100" 
                              value={editingTab.transmissionProb} 
                              onChange={e => updateEditingTabParam("transmissionProb", Number(e.target.value))} 
                              className="w-full h-1 bg-neutral-700 rounded-lg appearance-none cursor-pointer accent-rose-500" 
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[9px] font-bold text-neutral-400 uppercase flex justify-between">
                              <span>회복률</span>
                              <span className="font-mono text-emerald-400 font-extrabold">{editingTab.recoveryRate}%/s</span>
                            </label>
                            <input 
                              type="range" 
                              min="1" 
                              max="40" 
                              step="0.5" 
                              value={editingTab.recoveryRate} 
                              onChange={e => updateEditingTabParam("recoveryRate", Number(e.target.value))} 
                              className="w-full h-1 bg-neutral-700 rounded-lg appearance-none cursor-pointer accent-emerald-500" 
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-[9px] font-bold text-neutral-400 uppercase">백신 접종률 ({vaccinationRate}%)</label>
                            <input 
                              type="range" 
                              min="0" 
                              max="100" 
                              value={vaccinationRate} 
                              onChange={e => { setVaccinationRate(Number(e.target.value)); setIsRunning(false); }} 
                              className="w-full h-1 bg-neutral-700 rounded-lg appearance-none cursor-pointer accent-indigo-500" 
                            />
                          </div>
                          <div className="space-y-1">
                            <div className="flex justify-between items-center text-[9px] font-bold text-neutral-450">
                              <span className="uppercase">초기 감염자 ({initialInfectedCount}명)</span>
                            </div>
                            <input 
                              type="range" 
                              min="1" 
                              max={Math.min(100, n)} 
                              value={initialInfectedCount} 
                              onChange={e => { setInitialInfectedCount(Number(e.target.value)); setIsRunning(false); }} 
                              className="w-full h-1 bg-neutral-700 rounded-lg appearance-none cursor-pointer accent-rose-500" 
                            />
                            <div className="flex gap-1 justify-between mt-1">
                              {[1, 2, 5, 10, 20].map(cnt => (
                                <button
                                  key={cnt}
                                  onClick={() => {
                                    if (cnt <= n) {
                                      setInitialInfectedCount(cnt);
                                      setIsRunning(false);
                                    }
                                  }}
                                  disabled={cnt > n}
                                  className={`text-[8px] font-black px-1 py-0.5 rounded transition-all cursor-pointer ${
                                    initialInfectedCount === cnt 
                                      ? "bg-rose-600 text-white" 
                                      : "bg-neutral-800 text-neutral-400 hover:text-white"
                                  }`}
                                >
                                  {cnt}명
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="space-y-1 pt-1">
                          <label className="text-[9px] font-bold text-neutral-400 uppercase flex justify-between">
                            <span>면역 지속 기간 (Immunity Period)</span>
                            <span className="text-indigo-400 font-mono font-bold">{editingTab.immunityDuration}초</span>
                          </label>
                          <input 
                            type="range" 
                            min="2" 
                            max="60" 
                            value={editingTab.immunityDuration} 
                            onChange={e => updateEditingTabParam("immunityDuration", Number(e.target.value))} 
                            className="w-full h-1 bg-neutral-700 rounded-lg appearance-none cursor-pointer accent-indigo-500" 
                          />
                        </div>
                      </div>
                    );
                  })()}
                </div>

                {/* Demographics Birth & Death rates - Broadened Slider limits */}
                <div className="space-y-4 p-3 bg-neutral-900/60 rounded-2xl border border-neutral-800/50">
                  <p className="text-[9px] font-black uppercase text-blue-400 tracking-wide pb-1 border-b border-neutral-800">인구 변동 통계 (Birth / Death)</p>
                  
                  <div className="space-y-3">
                    <div className="space-y-1">
                      <div className="flex justify-between text-[9px] font-bold text-neutral-400">
                        <span>자연 출산율 (Birth Rate per sec)</span>
                        <span className="text-blue-400 font-mono font-black">{birthRate.toFixed(2)}%</span>
                      </div>
                      <input 
                        type="range" 
                        min="0" 
                        max="6" // Broadened to 6%
                        step="0.05" 
                        value={birthRate} 
                        onChange={e => setBirthRate(Number(e.target.value))} 
                        className="w-full h-1 bg-neutral-700 rounded-lg appearance-none cursor-pointer accent-blue-500" 
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-[9px] font-bold text-neutral-400">
                        <span>자연 사망률 (Natural Death Rate per sec)</span>
                        <span className="text-neutral-400 font-mono font-black">{naturalDeathRate.toFixed(2)}%</span>
                      </div>
                      <input 
                        type="range" 
                        min="0" 
                        max="6" // Broadened to 6%
                        step="0.05" 
                        value={naturalDeathRate} 
                        onChange={e => setNaturalDeathRate(Number(e.target.value))} 
                        className="w-full h-1 bg-neutral-700 rounded-lg appearance-none cursor-pointer accent-neutral-500" 
                      />
                    </div>

                    <div className="space-y-1">
                      {(() => {
                        const editingTab = diseaseTabs.find(t => t.id === editingTabId) || diseaseTabs[0];
                        return (
                          <>
                            <div className="flex justify-between text-[9px] font-bold text-neutral-400">
                              <span>감염 치명률 (Disease Fatality Rate per sec)</span>
                              <span className="text-rose-400 font-mono font-black">{editingTab.infectionDeathRate.toFixed(3)}%</span>
                            </div>
                            <input 
                              type="range" 
                              min="0" 
                              max="30" // Broadened to 30%
                              step="0.05" 
                              value={editingTab.infectionDeathRate} 
                              onChange={e => updateEditingTabParam("infectionDeathRate", Number(e.target.value))} 
                              className="w-full h-1 bg-neutral-700 rounded-lg appearance-none cursor-pointer accent-rose-600" 
                            />
                          </>
                        );
                      })()}
                    </div>
                  </div>
                </div>

              </div>
            </div>

            {/* Architectural Controls & Purposeful Navigation Options */}
            <div className="bg-neutral-800/60 p-6 rounded-3xl border border-neutral-700/40 space-y-4 backdrop-blur-md">
              <div className="flex items-center gap-2 text-xs font-bold text-neutral-200">
                <ShieldAlert size={16} className="text-amber-400" />
                <span>시나리오 건축 구조 및 경로 제어 설정</span>
              </div>

              <div className="space-y-4">
                {/* 1. Door Control Panel Button */}
                <div className="p-3.5 bg-neutral-900/50 rounded-2xl border border-neutral-800 space-y-2">
                  <div className="flex justify-between items-center">
                    <div className="space-y-0.5">
                      <span className="text-[10px] font-black uppercase tracking-wide text-neutral-300 flex items-center gap-1.5">
                        <Lock size={12} className="text-amber-400" /> 격리 차단문 (Doors)
                      </span>
                      <p className="text-[9px] text-neutral-400 font-medium">벽에 장착된 격리 슬라이딩 문 제어</p>
                    </div>
                    <div className="flex items-center gap-2">
                      {/* Keyboard shortcut indicator */}
                      <span className="inline-flex items-center gap-1 text-[8px] bg-neutral-800 border border-neutral-700/60 text-neutral-400 px-2 py-1 rounded-xl font-mono font-black shadow-inner leading-none">
                        Hotkey <kbd className="text-[9px] text-amber-400 bg-neutral-950 px-1 py-0.5 rounded-lg border border-neutral-800/80 leading-none">D</kbd>
                      </span>
                      <button
                        onClick={() => setDoorsClosed(!doorsClosed)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                          doorsClosed 
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30 hover:bg-amber-500/20 shadow-sm shadow-amber-500/5' 
                            : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/20 shadow-sm shadow-emerald-500/5'
                        }`}
                      >
                        {doorsClosed ? "🔒 모두 차단 (CLOSED)" : "🔓 개방 통과 (OPEN)"}
                      </button>
                    </div>
                  </div>
                </div>

                {/* 2. Destination Intention Control Toggle */}
                <div className="p-3.5 bg-neutral-900/50 rounded-2xl border border-neutral-800 space-y-2">
                  <div className="flex justify-between items-center">
                    <div className="space-y-0.5">
                      <span className="text-[10px] font-black uppercase tracking-wide text-neutral-300 flex items-center gap-1.5">
                        <Navigation size={12} className="text-rose-400" /> 목적 방향성 활성이동
                      </span>
                      <p className="text-[9px] text-neutral-400 font-medium">데스크, 구역별 전용 목적지 방문</p>
                    </div>
                    <button
                      onClick={() => setUseIntention(!useIntention)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                        useIntention
                          ? 'bg-rose-600 text-white shadow-md shadow-rose-950/20' 
                          : 'bg-neutral-700 text-neutral-300 border border-neutral-600'
                      }`}
                    >
                      {useIntention ? "🎯 목적지 지향 (INTENT)" : "🎲 무작위 부유 (RANDOM)"}
                    </button>
                  </div>
                </div>

                {/* 3. Improved Motion & Physics Precision Settings Panel */}
                <div className="p-3.5 bg-neutral-900/60 rounded-2xl border border-neutral-850 space-y-3">
                  <p className="text-[9px] font-black uppercase text-amber-400 tracking-wider pb-1 flex items-center gap-1 border-b border-neutral-800">
                    <Settings2 size={12} /> 이동 및 물리 엔진 고화질 개선 (Motion Engine)
                  </p>

                  {/* Toggle: Inter-Agent Elastic Physics */}
                  <div className="flex justify-between items-center bg-neutral-950/40 p-2 rounded-xl border border-neutral-850">
                    <div className="space-y-0.5 max-w-[170px]">
                      <span className="text-[9px] font-bold text-neutral-300 flex items-center gap-1">
                        💥 개체 탄성 충돌방지 {enableBallCollision ? "On" : "Off"}
                      </span>
                      <p className="text-[8px] text-neutral-500 font-medium leading-normal">개체 간 관성 충돌 및 비겹침 물리현상 연산</p>
                    </div>
                    <button
                      onClick={() => setEnableBallCollision(!enableBallCollision)}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                        enableBallCollision
                          ? 'bg-amber-500 text-neutral-950 hover:bg-amber-400 font-extrabold shadow-sm'
                          : 'bg-neutral-800 text-neutral-450 border border-neutral-700/50 hover:text-neutral-350'
                      }`}
                    >
                      {enableBallCollision ? "활성" : "비활성"}
                    </button>
                  </div>

                  {/* Toggle: Wall Slither & Sliding Mechanics */}
                  <div className="flex justify-between items-center bg-neutral-950/40 p-2 rounded-xl border border-neutral-850">
                    <div className="space-y-0.5 max-w-[170px]">
                      <span className="text-[9px] font-bold text-neutral-300 flex items-center gap-1">
                        🛹 벽 슬라이딩 제어 {slideAlongWalls ? "On" : "Off"}
                      </span>
                      <p className="text-[8px] text-neutral-500 font-medium leading-normal">벽면과 충돌 시 정지하지 않고 부드럽게 미끄러짐</p>
                    </div>
                    <button
                      onClick={() => setSlideAlongWalls(!slideAlongWalls)}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                        slideAlongWalls
                          ? 'bg-amber-500 text-neutral-950 hover:bg-amber-400 font-extrabold shadow-sm'
                          : 'bg-neutral-800 text-neutral-450 border border-neutral-700/50 hover:text-neutral-350'
                      }`}
                    >
                      {slideAlongWalls ? "활성" : "비활성"}
                    </button>
                  </div>

                  {/* Toggle: Brownian Micro-Wiggles */}
                  <div className="flex justify-between items-center bg-neutral-950/40 p-2 rounded-xl border border-neutral-850">
                    <div className="space-y-0.5 max-w-[170px]">
                      <span className="text-[9px] font-bold text-neutral-300 flex items-center gap-1">
                        🌾 미세 떨림 에뮬레이트 {enableWiggle ? "On" : "Off"}
                      </span>
                      <p className="text-[8px] text-neutral-500 font-medium leading-normal">실제 사람의 자연스러운 걸음걸이 불규칙성 추가</p>
                    </div>
                    <button
                      onClick={() => setEnableWiggle(!enableWiggle)}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                        enableWiggle
                          ? 'bg-amber-500 text-neutral-950 hover:bg-amber-400 font-extrabold shadow-sm'
                          : 'bg-neutral-800 text-neutral-450 border border-neutral-700/50 hover:text-neutral-350'
                      }`}
                    >
                      {enableWiggle ? "활성" : "비활성"}
                    </button>
                  </div>

                  {/* Slider: Steering Inertia Responsiveness */}
                  {useIntention && (
                    <div className="space-y-1 bg-neutral-950/20 p-2 rounded-xl border border-neutral-850">
                      <div className="flex justify-between text-[9px] font-bold text-neutral-450">
                        <span>스티어링 회전 관성 (Steering Force)</span>
                        <span className="text-amber-400 font-mono font-black">{steeringSpeed}%</span>
                      </div>
                      <input 
                        type="range" 
                        min="5" 
                        max="100" 
                        value={steeringSpeed} 
                        onChange={e => setSteeringSpeed(Number(e.target.value))} 
                        className="w-full h-1 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-500" 
                      />
                      <p className="text-[7.5px] text-neutral-500 leading-normal">수치가 낮을수록 중력감 있는 부드러운 코너링 궤적 연산</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Quick stats totals */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3.5 bg-rose-500/10 border border-rose-500/20 rounded-2xl">
                <div className="flex items-center gap-1.5 text-rose-400 mb-1">
                  <Heart size={12} />
                  <span className="text-[10px] font-black uppercase text-neutral-400">감염 개체 (Infected)</span>
                </div>
                <div className="text-2xl font-black text-rose-400 font-mono">{stats.infected}</div>
              </div>
              <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl">
                <div className="flex items-center gap-1.5 text-emerald-400 mb-1">
                  <Shield size={12} />
                  <span className="text-[10px] font-black uppercase text-neutral-400">명시적 항체 보유</span>
                </div>
                <div className="text-2xl font-black text-emerald-400 font-mono">{stats.recovered}</div>
              </div>
              <div className="p-3.5 bg-neutral-800 border border-neutral-700/60 rounded-2xl">
                <div className="flex items-center gap-1.5 text-neutral-400 mb-1">
                  <Users size={12} />
                  <span className="text-[10px] font-black uppercase text-neutral-400">현재 생존 인구</span>
                </div>
                <div className="text-2xl font-black text-white font-mono">{stats.alive}</div>
              </div>
              <div className="p-3.5 bg-neutral-800 border border-neutral-700/60 rounded-2xl">
                <div className="flex items-center gap-1.5 text-neutral-400 mb-1">
                  <Skull size={12} />
                  <span className="text-[10px] font-black uppercase text-neutral-400">총 누계 사망수</span>
                </div>
                <div className="text-2xl font-black text-neutral-400 font-mono">{stats.totalDeadCount}</div>
              </div>
            </div>
          </div>

          {/* Canvas & Graphs - Right */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* Simulation Arena */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
              
              <div className="md:col-span-7 bg-neutral-800/60 p-4 rounded-3xl border border-neutral-700/50 backdrop-blur-md relative">
                <div className="flex justify-between items-center mb-2 px-1">
                  <span className="text-xs font-black text-neutral-300 uppercase flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" /> Spatiotemporal Canvas Grid
                  </span>
                  <span className="font-mono text-xs font-black text-neutral-400">{Math.floor(elapsedTime)}s Elapsed</span>
                </div>
                
                <div className="relative w-full aspect-square bg-no-repeat bg-[#0c0d0e] rounded-2xl overflow-hidden border border-neutral-700/40">
                  <canvas 
                    ref={canvasRef} 
                    width={600} 
                    height={600} 
                    className="w-full h-full"
                  />
                  
                  <AnimatePresence>
                    {!isRunning && (
                      <motion.div 
                        initial={{ opacity: 0 }} 
                        animate={{ opacity: 1 }} 
                        exit={{ opacity: 0 }} 
                        className="absolute inset-0 bg-black/60 backdrop-blur-[1px] flex items-center justify-center p-6 text-center select-none"
                      >
                        <div className="max-w-xs space-y-2 bg-neutral-900 border border-neutral-800 p-6 rounded-2xl shadow-xl">
                          <p className="text-sm font-black text-neutral-200">입력 대기 모드</p>
                          <p className="text-xs text-neutral-400">상단의 [시뮬레이션 가동] 버튼을 클릭해 실시간 전파 상태를 봅니다.</p>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Vaccine Coverage Heatmap Floating Legend */}
                  {heatmapMode !== 'off' && (
                    <div className="absolute bottom-3 right-3 bg-neutral-950/90 backdrop-blur-md border border-neutral-800/80 rounded-xl p-2.5 shadow-xl max-w-[200px] space-y-2 text-[10px] z-10 select-none pointer-events-none transition-all">
                      <div className="flex items-center gap-1.5 font-bold text-neutral-200">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                        <span className="font-extrabold uppercase text-[9px] tracking-tight text-neutral-300">접종 커버리지 대시보드</span>
                      </div>
                      
                      <div className="space-y-1">
                        <div className="flex justify-between text-[8px] text-neutral-450 font-black uppercase tracking-tighter">
                          <span>취약 (0%)</span>
                          <span>안전 (100%)</span>
                        </div>
                        {/* Beautiful gradient spectrum */}
                        <div className="h-2 w-full rounded bg-gradient-to-r from-rose-500 via-amber-500 via-cyan-500 to-emerald-500 border border-neutral-900" />
                        <div className="flex justify-between text-[7px] font-mono font-bold text-neutral-450">
                          <span>Vulnerable</span>
                          <span>Moderate</span>
                          <span>Protected</span>
                        </div>
                      </div>

                      <div className="text-[8px] text-neutral-400 font-medium leading-normal border-t border-neutral-800/60 pt-1.5">
                        {heatmapMode === 'smooth' ? (
                          <p className="leading-tight">
                            <strong>커널 밀도 가중:</strong> 실시간 접종 완료자의 가중 분포 면역 장벽 시각화.
                          </p>
                        ) : (
                          <p className="leading-tight">
                            <strong>8×8 격자 집계:</strong> 구역 내 접종 완료자 비율(%) 직접 표시.
                          </p>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Immunity rate graph panel */}
              <div className="md:col-span-5 bg-neutral-800/60 p-6 rounded-3xl border border-neutral-700/50 backdrop-blur-md flex flex-col justify-between h-full min-h-[420px]">
                <div>
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h4 className="text-xs font-black text-neutral-200 uppercase flex items-center gap-1.5">
                        <Shield size={14} className="text-emerald-400" /> 실시간 항체 보유율
                      </h4>
                      <p className="text-[10px] text-neutral-400 font-semibold tracking-tight mt-0.5">생존 인구 중 면역 획득자 흐름</p>
                    </div>
                    <div className="text-right">
                      <span className="text-xl font-bold font-mono text-emerald-400">{stats.immunityRate.toFixed(1)}%</span>
                      <p className="text-[8px] text-neutral-400 font-extrabold uppercase">State Rate</p>
                    </div>
                  </div>
                  
                  <div className="h-44 bg-neutral-900/40 rounded-2xl p-2 border border-neutral-800/50">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={history}>
                        <defs>
                          <linearGradient id="colorGreen" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#10b981" stopOpacity={0.15}/>
                            <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1f2937" />
                        <XAxis dataKey="time" hide />
                        <YAxis domain={[0, 100]} hide />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#171717', borderRadius: '12px', border: '1px solid #333', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.5)' }}
                          itemStyle={{ fontSize: '9px', fontWeight: '800', textTransform: 'uppercase', color: '#10b981' }}
                        />
                        <Area 
                          type="monotone" 
                          dataKey={(d) => d.total > 0 ? (d.recovered / (d.susceptible + d.infected + d.recovered)) * 100 : 0} 
                          name="Immunity (%)"
                          stroke="#10b981" 
                          fillOpacity={1} 
                          fill="url(#colorGreen)" 
                          strokeWidth={2}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-neutral-700/40 text-neutral-400 space-y-3">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-[10px] text-neutral-300">인당 유효 접촉 빈도 (60초당)</span>
                    <span className="font-mono font-bold text-white bg-neutral-900 px-2 py-0.5 rounded-lg border border-neutral-800">{contactRatePer60s.toFixed(2)}회</span>
                  </div>
                  <div className="p-3 bg-rose-500/5 border border-rose-500/10 rounded-xl leading-relaxed text-[10px] text-neutral-300">
                    <span className="font-black text-rose-400 block mb-1">STOCHASTIC DECISIONS</span>
                    0.1초마다 미세 상태 진동을 거치고, 죽은 물체는 회색으로 변한 직후 약 0.8초간 오파시티 가중치가 감소하여 스러집니다.
                  </div>
                </div>
              </div>

            </div>

            {/* SEIR dynamics chart */}
            <div className="bg-neutral-800/60 p-6 rounded-3xl border border-neutral-700/50 backdrop-blur-md">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <TrendingUp size={18} className="text-rose-400" />
                  <h3 className="text-xs font-black text-neutral-200 uppercase tracking-wide">실시간 인구 상태 트렌드 지표</h3>
                </div>
                <span className="text-[10px] text-neutral-500 font-extrabold font-mono">{history.length} Time points</span>
              </div>
              
              <div className="h-48 bg-neutral-900/40 rounded-2xl p-2 border border-neutral-800/50">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={history}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1f2937" />
                    <XAxis dataKey="time" stroke="#6b7280" fontSize={9} tickLine={false} axisLine={false} />
                    <YAxis stroke="#6b7280" fontSize={9} tickLine={false} axisLine={false} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#171717', borderRadius: '12px', border: '1px solid #333' }}
                      labelStyle={{ fontSize: '10px', color: '#9ca3af' }}
                    />
                    <Line type="monotone" dataKey="susceptible" stroke="#3b82f6" strokeWidth={2.5} dot={false} name="S (Susceptible)" />
                    <Line type="monotone" dataKey="infected" stroke="#ef4444" strokeWidth={2.5} dot={false} name="I (Infected)" />
                    <Line type="monotone" dataKey="recovered" stroke="#10b981" strokeWidth={2.5} dot={false} name="R (Recovered)" />
                    <Line type="monotone" dataKey="dead" stroke="#9ca3af" strokeWidth={1.5} dot={false} name="Dead (Total)" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              
              <div className="grid grid-cols-4 gap-2 mt-4 text-[10px] text-center font-black">
                <div className="p-1 px-2.5 bg-blue-500/10 text-blue-400 rounded-xl border border-blue-500/10">S: Susceptible</div>
                <div className="p-1 px-2.5 bg-rose-500/10 text-rose-400 rounded-xl border border-rose-500/10">I: Infected</div>
                <div className="p-1 px-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/10">R: Recovered</div>
                <div className="p-1 px-2.5 bg-neutral-500/10 text-neutral-400 rounded-xl border border-neutral-500/10">D: Dead Accum.</div>
              </div>
            </div>

            {/* 감염병 비교 대시보드 - REAL-TIME EPIDEMIC COMPILER GRID */}
            <div className="bg-neutral-800/60 p-6 rounded-3xl border border-neutral-700/50 backdrop-blur-md space-y-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <BarChart3 size={18} className="text-amber-400" />
                  <div>
                    <h3 className="text-xs font-black text-neutral-200 uppercase tracking-wide">
                      글로벌 실제 전염병 vs 시뮬레이션 지표 동역학 비교 대시보드
                    </h3>
                    <p className="text-[10px] text-neutral-400">
                      실제 의학/사회적 전염 매개변수와 실시간 물리 충돌 엔진에서 수집된 시뮬레이션 모델 지표의 수리적 격차 분석 (💡 <span className="text-rose-400 font-bold">임의의 전염병 행을 클릭</span>하면 해당 물리/역학 매개변수로 시뮬레이션이 즉각 리셋 및 시작됩니다)
                    </p>
                  </div>
                </div>
                
                {/* Reset Empirical Data Button */}
                <button
                  onClick={() => {
                    empiricalStatsRef.current = {
                      completedCount: 0,
                      totalSecondaryInfections: 0,
                      totalDuration: 0,
                      diseaseDeaths: 0,
                      recoveries: 0
                    };
                    setEmpiricalStats({
                      completedCount: 0,
                      totalSecondaryInfections: 0,
                      totalDuration: 0,
                      diseaseDeaths: 0,
                      recoveries: 0
                    });
                  }}
                  className="px-3 py-1.5 rounded-lg bg-neutral-750 hover:bg-neutral-700 border border-neutral-600/40 text-[10px] font-bold text-neutral-300 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw size={10} />
                  실측 데이터 누계 초기화
                </button>
              </div>

              {/* Table Container */}
              <div className="overflow-x-auto rounded-2xl border border-neutral-700/30">
                <table className="w-full text-[11px] text-left border-collapse bg-neutral-900/20">
                  <thead>
                    <tr className="bg-neutral-900/60 text-neutral-400 border-b border-neutral-700/50 font-black text-[10px] uppercase">
                      <th className="p-3">전염병 / 지표 유형</th>
                      <th className="p-3 text-center">기초 감염 재생산 수 (R₀)</th>
                      <th className="p-3 text-center">Infection Fatality Rate (치명률)</th>
                      <th className="p-3 text-center">감염 유지 기간</th>
                      <th className="p-3">지표 성격 및 물리 모델 병행 대조</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-800/40">
                    {/* Render Real World Diseases & Custom Tabs dynamically */}
                    {diseaseTabs.map((tab) => {
                      const isEditing = editingTabId === tab.id;
                      const tabColor = getDiseaseColor(tab.id, diseaseTabs);
                      return (
                        <tr 
                          key={tab.id} 
                          onClick={() => {
                            setEditingTabId(tab.id);
                          }}
                          className={`cursor-pointer transition-all group ${
                            isEditing 
                              ? "bg-rose-950/20 text-white hover:bg-rose-950/30" 
                              : "text-neutral-300 hover:bg-neutral-800/20"
                          }`}
                        >
                          <td className="p-3 font-bold text-neutral-200">
                            <span className="inline-flex items-center gap-2">
                              {/* Color bullet dot */}
                              <span
                                className="w-2.5 h-2.5 rounded-full relative flex-shrink-0"
                                style={{ backgroundColor: tabColor }}
                              >
                                <span className="absolute inset-0 rounded-full bg-current animate-ping opacity-25" />
                              </span>
                              <span className={isEditing ? "text-rose-400 font-extrabold" : ""}>
                                {tab.name}
                              </span>
                              <span className="text-[9px] px-1.5 py-0.5 rounded bg-rose-500/10 text-rose-300 font-black leading-none">
                                가공 가동 중
                              </span>
                              {isEditing && (
                                <span className="text-[9px] px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-400 font-bold leading-none animate-pulse">
                                  편집 개방
                                </span>
                              )}
                            </span>
                          </td>
                          <td className="p-3 text-center font-mono font-bold text-white">
                            {tab.presetKey === "custom" ? (tab.transmissionProb / 10).toFixed(1) + " ~ " + (tab.transmissionProb / 5).toFixed(1) : tab.r0}
                          </td>
                          <td className="p-3 text-center font-mono font-semibold text-rose-300 bg-rose-950/5">
                            {tab.presetKey === "custom" ? (tab.infectionDeathRate * 3).toFixed(1) + "%" : tab.ifr}
                          </td>
                          <td className="p-3 text-center font-mono text-neutral-400">
                            {tab.presetKey === "custom" ? `${tab.immunityDuration}초` : tab.duration}
                          </td>
                          <td className="p-3 text-neutral-400 text-[10px] leading-relaxed group-hover:text-neutral-200 transition-colors">
                            {tab.desc} <span className="text-[9px] text-rose-400 font-bold font-mono">(전파 {tab.transmissionProb}%, 회복 {tab.recoveryRate}%, 치명 {tab.infectionDeathRate.toFixed(2)}%, 지속 {tab.immunityDuration}초)</span>
                          </td>
                        </tr>
                      );
                    })}

                    {/* Simulation - Math Model Predictive row */}
                    <tr className="bg-amber-500/5 hover:bg-amber-500/10 border-t-2 border-amber-500/30 transition-colors">
                      <td className="p-3 font-black text-amber-400">
                        <span className="inline-flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                          시뮬레이션 (이론 예측 지표)
                        </span>
                      </td>
                      <td className="p-3 text-center bg-amber-950/10">
                        <div className="font-mono font-extrabold text-amber-300 text-xs">
                          {theoreticalR0Val.toFixed(2)}
                        </div>
                        <div className="text-[8px] text-amber-500 font-bold uppercase mt-0.5">Calculated Th.</div>
                      </td>
                      <td className="p-3 text-center bg-amber-950/10">
                        <div className="font-mono font-extrabold text-rose-400 text-xs">
                          {theoreticalIFRVal.toFixed(1)}%
                        </div>
                        <div className="text-[8px] text-neutral-500 font-bold uppercase mt-0.5">Mathematical</div>
                      </td>
                      <td className="p-3 text-center bg-amber-950/10">
                        <div className="font-mono font-semibold text-neutral-300 text-xs">
                          {theoreticalDurationVal.toFixed(1)}초
                        </div>
                        <div className="text-[8px] text-neutral-500 font-bold uppercase mt-0.5">Virtual Days</div>
                      </td>
                      <td className="p-3 text-neutral-300 text-[10px] leading-relaxed font-semibold">
                        슬라이더 조작 수치를 기반으로 한 <span className="font-bold text-amber-400">결정론적 이론 추정값 (Deterministic SIR)</span>입니다. 물리적 외벽이나 기동 속도의 저하, 격리 조치 등이 완전히 차단되지 않은 균일 접촉성 이상 기체 공간을 전제합니다.
                      </td>
                    </tr>

                    {/* Simulation - Live Tracked Empirical row */}
                    <tr className="bg-indigo-500/5 hover:bg-indigo-500/10 border-t border-indigo-500/30 transition-colors">
                      <td className="p-3 font-black text-indigo-400">
                        <span className="inline-flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
                          시뮬레이션 (실측 동역학 지표)
                        </span>
                      </td>
                      <td className="p-3 text-center bg-indigo-950/10">
                        <div className="font-mono font-extrabold text-indigo-300 text-xs">
                          {empiricalR0Val.toFixed(2)}
                        </div>
                        <div className="text-[8px] text-indigo-500 font-bold uppercase mt-0.5">Observed Live</div>
                      </td>
                      <td className="p-3 text-center bg-indigo-950/10">
                        <div className="font-mono font-extrabold text-rose-400 text-xs">
                          {empiricalIFRVal.toFixed(1)}%
                        </div>
                        <div className="text-[8px] text-neutral-500 font-bold uppercase mt-0.5">Empirical Deaths</div>
                      </td>
                      <td className="p-3 text-center bg-indigo-950/10">
                        <div className="font-mono font-semibold text-neutral-300 text-xs">
                          {empiricalDurationVal.toFixed(1)}초
                        </div>
                        <div className="text-[8px] text-neutral-500 font-bold uppercase mt-0.5">Completed {empiricalStats.completedCount}건</div>
                      </td>
                      <td className="p-3 text-neutral-300 text-[10px] leading-relaxed font-semibold">
                        실시간 공간 충돌 엔진 안에서 실제로 병에 걸려 치료되거나 사망한 피실험자들의 <span className="font-bold text-indigo-400">확률 추적 가시 측정값</span>입니다. 격리 벽면, 이동 방향, 충돌 패턴 등의 실제 구조적 제약을 온전히 반영합니다.
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Difference and Educational Analytics */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                <div className="p-4 bg-amber-500/5 border border-amber-500/10 rounded-2xl space-y-2">
                  <div className="flex items-center gap-1.5 text-amber-400 font-black text-xs uppercase">
                    <Info size={12} />
                    <span>이론 치명률 vs 실측 치명률 격차 분석</span>
                  </div>
                  <p className="text-[10px] text-neutral-300 leading-relaxed font-semibold">
                    이론 치명률(정밀 예측값: <span className="font-mono font-bold text-amber-300">{theoreticalIFRVal.toFixed(1)}%</span>)은 질병 자체 원인의 회복 및 사망 전이율에 고정되지만, 실측 치명률(<span className="font-mono font-bold text-indigo-300">{empiricalIFRVal.toFixed(1)}%</span>)은 확률 분포 상 무작위 표본 편차(Stochastic Variance)에 따라 일시적 편차를 갖습니다. 데이터 샘플 누계가 축적될수록 이론값으로 점진 수렴합니다.
                  </p>
                </div>

                <div className="p-4 bg-indigo-500/5 border border-indigo-500/10 rounded-2xl space-y-2">
                  <div className="flex items-center gap-1.5 text-indigo-400 font-black text-xs uppercase">
                    <Shield size={12} />
                    <span>격리 차막막 및 군집 밀도의 감쇠 효과</span>
                  </div>
                  <p className="text-[10px] text-neutral-300 leading-relaxed font-semibold">
                    실제 전파 재생산 수(실측 R₀: <span className="font-mono font-bold text-indigo-300">{empiricalR0Val.toFixed(2)}</span>)와 수학 계산 예측 R₀(<span className="font-mono font-bold text-amber-300">{theoreticalR0Val.toFixed(2)}</span>)의 격차율은 물리 공간 제약의 수리 지표입니다. <span className="font-bold text-emerald-400">슬라이딩 도어를 닫아 벽을 형성하거나 기동 빈도를 차단하면 실측 R₀ 값이 이론 R₀ 값보다 강력하게 주저앉아 감쇄됨</span>을 관찰할 수 있으며, 이는 환경 격리의 공중 보건 기여도를 입증합니다.
                  </p>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>

      {/* Python Stochastic SEIR Reference Drawer/Modal */}
      <AnimatePresence>
        {isPythonModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-neutral-800 border border-neutral-700 w-full max-w-3xl rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]"
            >
              <div className="p-6 border-b border-neutral-700 flex justify-between items-center bg-neutral-900/50">
                <div className="flex items-center gap-2.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
                  <div>
                    <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                      Stochastic SEIR Python Code Generator
                    </h3>
                    <p className="text-[10px] text-neutral-400 font-semibold tracking-tight mt-0.5">확률적 미분 연산 및 앙상블 편차 그래프 생성 소스코드</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsPythonModalOpen(false)}
                  className="p-1.5 rounded-xl hover:bg-neutral-700 text-neutral-400 hover:text-white transition-all cursor-pointer"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="p-6 overflow-y-auto space-y-4 text-xs leading-relaxed text-neutral-300">
                <div className="p-4 bg-amber-500/5 border border-amber-500/10 rounded-2xl space-y-2">
                  <span className="text-[10px] font-black uppercase text-amber-400 block tracking-wider">stochastic SEIR 수학적 로직 설명</span>
                  <p>
                    이 시뮬레이셔널 파이썬 스크립트는 이항 분포와 포아송 확률밀도 분포를 따릅니다. 
                    접촉 당 감염 확률 및 하루 평균 접촉 횟수를 분할하여 질병확장 메커니즘을 규명하고, 여러 회차 반복 실행(Monte Carlo Ensemble)을 통해 분산 편차를 오버레이 시각화하게 되어 불확정성을 완벽하게 증명합니다.
                  </p>
                </div>

                <div className="relative">
                  <div className="absolute top-3 right-3 flex items-center gap-2 z-10">
                    <button
                      onClick={copyToClipboard}
                      className="p-2 py-1.5 rounded-lg bg-neutral-700 hover:bg-neutral-600 text-white font-bold flex items-center gap-1 cursor-pointer select-none"
                    >
                      {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                      {copied ? '복사됨!' : '코드 복사'}
                    </button>
                    <button
                      onClick={downloadPythonScript}
                      className="p-2 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold flex items-center gap-1 cursor-pointer select-none"
                    >
                      <Download size={12} />
                      다운로드 (.py)
                    </button>
                  </div>
                  
                  <textarea
                    readOnly
                    value={pythonScriptText}
                    className="w-full h-80 bg-neutral-950 text-emerald-400 p-4 rounded-2xl font-mono text-[10px] outline-none border border-neutral-900 resize-none pt-12 select-all scrollbar-thin"
                  />
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
